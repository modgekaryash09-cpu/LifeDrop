package com.blooddonor.app

import android.app.Application
import com.blooddonor.app.data.AppStore

class BloodDonorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppStore.init(this)
    }
}
