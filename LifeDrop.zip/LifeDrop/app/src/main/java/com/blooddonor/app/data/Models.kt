package com.blooddonor.app.data

data class Donor(
    val id: Int,
    val name: String,
    val bloodGroup: String,
    val gender: String,
    val age: Int,
    val distanceKm: Int,
    val city: String,
    val phone: String,
    val email: String,
    val lastDonation: String,
    val available: Boolean,
    /** Position of the donor pin on the nearby map (0..1 of width/height). */
    val mapX: Float,
    val mapY: Float,
    /** Blood bank this donor is registered with (0 = none). */
    val bankId: Int = 0,
    val bankName: String = "",
    /** App account behind this donor record (0 = added by an admin). */
    val userId: Long = 0
)

data class Donation(val date: String, val bloodGroup: String, val units: Int)

data class BloodRequest(
    val id: String,
    val date: String,
    val bloodGroup: String,
    val units: String,
    val hospital: String,
    val reason: String,
    val status: String
)

data class User(
    val fullName: String,
    val phone: String,
    val email: String,
    val bloodGroup: String,
    val location: String
)

data class UserRow(
    val id: Long,
    val fullName: String,
    val email: String,
    val phone: String,
    val bloodGroup: String,
    /** 0 = donor / user, 1 = blood bank admin, 2 = super admin. */
    val role: Int,
    val bankName: String = ""
) {
    val isAdmin: Boolean get() = role >= 1
    val roleLabel: String
        get() = when (role) {
            1 -> if (bankName.isEmpty()) "Bank Admin" else "Bank Admin - $bankName"
            2 -> "Super Admin"
            else -> ""
        }
}

data class AdminRequest(val request: BloodRequest, val requesterName: String)

data class AdminStats(val users: Int, val donors: Int, val requests: Int, val pending: Int)

data class BloodBank(
    val id: Long,
    val name: String,
    val city: String,
    val address: String,
    val phone: String,
    val email: String,
    /** PENDING, APPROVED or REJECTED. */
    val status: String,
    val distanceKm: Int,
    val totalUnits: Int,
    val adminNames: String
)

data class DonationRequest(
    val id: Long,
    val userName: String,
    val bankId: Long,
    val bankName: String,
    val bloodGroup: String,
    val units: Int,
    val preferredDate: String,
    /** Pending, Approved or Rejected. */
    val status: String
)

data class StockRow(val bloodGroup: String, val units: Int)

/** One line of a statistics screen. */
data class StatLine(val label: String, val value: String)
