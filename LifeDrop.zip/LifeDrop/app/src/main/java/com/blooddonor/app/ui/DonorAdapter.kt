package com.blooddonor.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.blooddonor.app.R
import com.blooddonor.app.data.Donor
import com.blooddonor.app.databinding.ItemDonorBinding

class DonorAdapter(
    private val onItemClick: (Donor) -> Unit,
    private val onCallClick: (Donor) -> Unit
) : ListAdapter<Donor, DonorAdapter.VH>(Diff) {

    class VH(val b: ItemDonorBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemDonorBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = getItem(position)
        val ctx = holder.b.root.context
        holder.b.tvName.text = d.name
        holder.b.tvInfo.text = "${d.bloodGroup}  |  ${d.gender}  |  ${d.distanceKm} km"
        if (d.available) {
            holder.b.tvStatus.text = "Available"
            holder.b.tvStatus.setTextColor(ctx.getColor(R.color.green))
            holder.b.tvStatus.setBackgroundResource(R.drawable.bg_badge)
        } else {
            holder.b.tvStatus.text = "Unavailable"
            holder.b.tvStatus.setTextColor(ctx.getColor(R.color.muted))
            holder.b.tvStatus.setBackgroundResource(R.drawable.bg_badge_off)
        }
        holder.b.root.setOnClickListener { onItemClick(d) }
        holder.b.btnCall.setOnClickListener { onCallClick(d) }
    }

    object Diff : DiffUtil.ItemCallback<Donor>() {
        override fun areItemsTheSame(a: Donor, b: Donor) = a.id == b.id
        override fun areContentsTheSame(a: Donor, b: Donor) = a == b
    }
}
