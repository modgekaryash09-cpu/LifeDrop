package com.blooddonor.app.ui

import android.app.Activity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.BankStore
import com.blooddonor.app.data.BloodBank

/** Donor registers (or updates) their donor profile with a blood bank. */
fun Activity.showRegisterDonorDialog(onDone: () -> Unit = {}) {
    val banks = BankStore.approvedBanks()
    if (banks.isEmpty()) { toast("No blood banks available yet"); return }
    val mine = AppStore.myDonor()
    val labels = banks.map { "${it.name} (${it.distanceKm} km)" }
    val groups = resources.getStringArray(R.array.blood_groups).toList()
    val genders = resources.getStringArray(R.array.genders).toList()
    val currentBank = banks.indexOfFirst { it.id == (mine?.bankId ?: 0).toLong() }
    showForm(
        title = if (mine == null) "Register as Blood Donor" else "Update Donor Registration",
        fields = listOf(
            Field("bank", "Blood bank", FieldType.CHOICE, labels, labels[currentBank.coerceAtLeast(0)]),
            Field("group", "Blood group", FieldType.CHOICE, groups, mine?.bloodGroup ?: AppStore.getUser().bloodGroup),
            Field("gender", "Gender", FieldType.CHOICE, genders, mine?.gender ?: genders.first()),
            Field("age", "Age", FieldType.NUMBER, initial = mine?.age?.toString() ?: "")
        ),
        positive = if (mine == null) "Register" else "Update"
    ) { v ->
        val age = v.getValue("age").toInt()
        if (age !in 18..65) return@showForm "Donors must be 18 to 65 years old"
        val bank = banks[labels.indexOf(v.getValue("bank")).coerceAtLeast(0)]
        BankStore.registerAsDonor(bank.id, v.getValue("group"), v.getValue("gender"), age)
        toast("You are registered as a donor with ${bank.name}")
        onDone()
        null
    }
}

/** Donor asks a bank to accept a blood donation. */
fun Activity.showDonateDialog(bank: BloodBank) {
    val groups = resources.getStringArray(R.array.blood_groups).toList()
    showForm(
        title = "Donate at ${bank.name}",
        fields = listOf(
            Field("group", "Blood group", FieldType.CHOICE, groups, AppStore.getUser().bloodGroup),
            Field("units", "Units", FieldType.CHOICE, listOf("1", "2"), "1"),
            Field("date", "Preferred date", FieldType.TEXT, initial = BankStore.today())
        ),
        positive = "Send request"
    ) { v ->
        BankStore.createDonationRequest(bank.id, v.getValue("group"), v.getValue("units").toInt(), v.getValue("date"))
        toast("Donation request sent to ${bank.name}")
        null
    }
}

/** A user applies to register a new blood bank (needs Super Admin approval). */
fun Activity.showRegisterBankDialog() {
    showForm(
        title = "Register Blood Bank",
        fields = listOf(
            Field("name", "Blood bank name"),
            Field("address", "Address"),
            Field("phone", "Phone", FieldType.PHONE),
            Field("email", "Email", FieldType.EMAIL)
        ),
        positive = "Submit"
    ) { v ->
        if (BankStore.registerBankByUser(v.getValue("name"), v.getValue("address"), v.getValue("phone"), v.getValue("email"))) {
            toast("Submitted. A Super Admin will review it.")
            null
        } else "You already have a registration waiting for approval"
    }
}
