package com.blooddonor.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.UserRow
import com.blooddonor.app.databinding.ActivityAdminUsersBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class AdminUsersActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminUsersBinding
    private lateinit var adapter: AdminUserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAdminUsersBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        adapter = AdminUserAdapter { confirmDelete(it) }
        b.rv.adapter = adapter
        load()
    }

    private fun load() {
        val list = AppStore.allUsers()
        adapter.submitList(list)
        b.tvEmpty.text = "No users yet"
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmDelete(user: UserRow) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete user")
            .setMessage("Delete ${user.fullName}? Their blood requests and donations are deleted too.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                AppStore.deleteUser(user.id)
                toast("User deleted")
                load()
            }
            .show()
    }
}
