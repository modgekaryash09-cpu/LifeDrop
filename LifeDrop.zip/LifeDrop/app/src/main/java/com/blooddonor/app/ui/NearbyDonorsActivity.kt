package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.Donor
import com.blooddonor.app.databinding.ActivityNearbyDonorsBinding

class NearbyDonorsActivity : AppCompatActivity() {
    private lateinit var b: ActivityNearbyDonorsBinding
    private var selected: Donor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNearbyDonorsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        b.map.donors = AppStore.donors
        b.map.onDonorSelected = { showDonor(it) }
        b.btnCall.setOnClickListener { selected?.let { d -> dial(d.phone) } }
        b.cardDonor.setOnClickListener {
            selected?.let { d ->
                openScreen<DonorProfileActivity> { putExtra(DonorProfileActivity.EXTRA_DONOR_ID, d.id) }
            }
        }

        // Start with the closest available donor selected.
        AppStore.donors.filter { it.available }.minByOrNull { it.distanceKm }?.let { showDonor(it) }
    }

    private fun showDonor(d: Donor) {
        selected = d
        b.map.selectedId = d.id
        b.tvName.text = d.name
        b.tvInfo.text = "${d.bloodGroup}  |  ${d.distanceKm} km"
        if (d.available) {
            b.tvStatus.text = "Available"
            b.tvStatus.setTextColor(getColor(R.color.green))
            b.tvStatus.setBackgroundResource(R.drawable.bg_badge)
        } else {
            b.tvStatus.text = "Unavailable"
            b.tvStatus.setTextColor(getColor(R.color.muted))
            b.tvStatus.setBackgroundResource(R.drawable.bg_badge_off)
        }
    }
}
