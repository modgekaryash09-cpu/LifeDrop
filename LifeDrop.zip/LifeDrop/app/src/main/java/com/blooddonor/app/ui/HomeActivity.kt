package com.blooddonor.app.ui

import android.os.Bundle
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {
    private lateinit var b: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.cardFindDonors.setOnClickListener { openScreen<FindDonorsActivity>() }
        b.cardRequestBlood.setOnClickListener { openScreen<RequestBloodActivity>() }
        b.cardMyDonations.setOnClickListener { openScreen<MyDonationsActivity>() }
        b.cardProfile.setOnClickListener { openScreen<ProfileActivity>() }
        b.btnNotifications.setOnClickListener { openScreen<NotificationSettingsActivity>() }
        b.btnMenu.setOnClickListener { showMenu() }

        b.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_donors -> openScreen<FindDonorsActivity>()
                R.id.nav_requests -> openRequests()
                R.id.nav_profile -> openScreen<ProfileActivity>()
            }
            // Keep "Home" highlighted because this is the Home screen.
            false
        }
    }

    private fun openRequests() {
        val last = AppStore.lastRequest()
        if (last != null) {
            openScreen<RequestStatusActivity> { putExtra(RequestStatusActivity.EXTRA_REQUEST_ID, last.id) }
        } else {
            openScreen<RequestBloodActivity>()
        }
    }

    private fun showMenu() {
        val popup = PopupMenu(this, b.btnMenu)
        popup.menu.add(0, 1, 0, "My Donations")
        popup.menu.add(0, 2, 1, "Nearby Donors")
        popup.menu.add(0, 6, 2, "Nearby Blood Banks")
        popup.menu.add(0, 7, 3, if (AppStore.hasDonorProfile()) "Update Donor Registration" else "Register as Donor")
        popup.menu.add(0, 8, 4, "My Requests")
        if (!AppStore.isAdmin()) popup.menu.add(0, 9, 5, "Register Blood Bank")
        popup.menu.add(0, 3, 6, "About App")
        if (AppStore.isAdmin()) {
            popup.menu.add(0, 5, 7, if (AppStore.isSuperAdmin()) "Super Admin Dashboard" else "Blood Bank Dashboard")
        }
        popup.menu.add(0, 4, 8, "Logout")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openScreen<MyDonationsActivity>()
                2 -> openScreen<NearbyDonorsActivity>()
                3 -> openScreen<AboutActivity>()
                4 -> confirmLogout()
                5 -> {
                    AppStore.adminMode = true
                    openAdminFresh()
                }
                6 -> openScreen<ListScreenActivity> { putExtra(ListScreenActivity.EXTRA_MODE, ListScreenActivity.MODE_NEARBY_BANKS) }
                7 -> showRegisterDonorDialog()
                8 -> openScreen<ListScreenActivity> { putExtra(ListScreenActivity.EXTRA_MODE, ListScreenActivity.MODE_MY_REQUESTS) }
                9 -> showRegisterBankDialog()
            }
            true
        }
        popup.show()
    }
}
