package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityNotificationSettingsBinding
import com.google.android.material.switchmaterial.SwitchMaterial

class NotificationSettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityNotificationSettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        bind(b.swNewRequests, "new_requests", true)
        bind(b.swDonorNearby, "donor_nearby", true)
        bind(b.swReminders, "reminders", true)
        bind(b.swAppUpdates, "app_updates", false)
        bind(b.swPromotions, "promotions", false)
    }

    private fun bind(toggle: SwitchMaterial, key: String, default: Boolean) {
        toggle.isChecked = AppStore.getNotif(key, default)
        toggle.setOnCheckedChangeListener { _, checked -> AppStore.setNotif(key, checked) }
    }
}
