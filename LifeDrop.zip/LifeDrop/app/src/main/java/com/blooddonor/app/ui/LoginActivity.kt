package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnLogin.setOnClickListener { doLogin() }
        b.tvSignUp.setOnClickListener { openScreen<SignUpActivity>() }
        b.tvForgot.setOnClickListener { showForgotPasswordDialog() }
        b.btnGoogle.setOnClickListener {
            toast("Google sign-in needs Firebase setup. Please login with email.")
        }
    }

    private fun doLogin() {
        b.tilEtEmailPhone.error = null
        b.tilEtPassword.error = null
        val id = b.etEmailPhone.text.toString().trim()
        val password = b.etPassword.text.toString()
        if (id.isEmpty()) {
            b.tilEtEmailPhone.error = "Enter your email or phone number"
            return
        }
        if (password.isEmpty()) {
            b.tilEtPassword.error = "Enter your password"
            return
        }
        if (AppStore.login(id, password)) {
            routeAfterLogin()
        } else {
            b.tilEtPassword.error = "Incorrect email/phone or password"
        }
    }
}
