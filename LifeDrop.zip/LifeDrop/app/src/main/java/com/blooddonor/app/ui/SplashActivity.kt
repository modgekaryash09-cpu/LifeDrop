package com.blooddonor.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore

class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val goNext = Runnable {
        val target = when {
            !AppStore.isLoggedIn() -> WelcomeActivity::class.java
            AppStore.isAdmin() && AppStore.adminMode ->
                AdminDashboardActivity::class.java
            else -> HomeActivity::class.java
        }
        startActivity(Intent(this, target))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        handler.postDelayed(goNext, 1800)
    }

    override fun onDestroy() {
        handler.removeCallbacks(goNext)
        super.onDestroy()
    }
}
