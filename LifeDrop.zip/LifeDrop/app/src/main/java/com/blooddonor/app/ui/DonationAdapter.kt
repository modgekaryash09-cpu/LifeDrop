package com.blooddonor.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.blooddonor.app.data.Donation
import com.blooddonor.app.databinding.ItemDonationBinding

class DonationAdapter(
    private val items: List<Donation>,
    private val onCertificate: (Donation) -> Unit
) : RecyclerView.Adapter<DonationAdapter.VH>() {

    class VH(val b: ItemDonationBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemDonationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = items[position]
        holder.b.tvDate.text = d.date
        val unitLabel = if (d.units == 1) "Unit" else "Units"
        holder.b.tvInfo.text = "${d.bloodGroup}  |  ${d.units} $unitLabel"
        holder.b.tvCertificate.setOnClickListener { onCertificate(d) }
    }
}
