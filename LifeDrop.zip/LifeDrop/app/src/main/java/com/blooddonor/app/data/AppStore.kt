package com.blooddonor.app.data

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Single access point for app data.
 * Accounts, donors, donations and blood requests live in SQLite ([BloodDonorDb]).
 * The logged-in user id and notification switches live in SharedPreferences.
 */
object AppStore {
    private const val PREF = "blood_donor_prefs"
    private const val KEY_USER = "current_user_id"

    private lateinit var prefs: SharedPreferences
    private lateinit var helper: BloodDonorDb

    internal val rdb: SQLiteDatabase get() = helper.readableDatabase
    internal val wdb: SQLiteDatabase get() = helper.writableDatabase

    fun init(context: Context) {
        if (::helper.isInitialized) return
        val app = context.applicationContext
        prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        helper = BloodDonorDb(app)
        helper.writableDatabase // create / open the database now
    }

    internal val currentUserId: Long get() = prefs.getLong(KEY_USER, -1L)

    // ------------------------------------------------------------------ account
    fun isLoggedIn(): Boolean {
        val id = currentUserId
        return id > 0 && DatabaseUtils.queryNumEntries(rdb, "users", "id = ?", arrayOf(id.toString())) > 0
    }

    fun logout() {
        prefs.edit().remove(KEY_USER).apply()
    }

    fun getUser(): User =
        rdb.rawQuery(
            "SELECT full_name, phone, email, blood_group, location FROM users WHERE id = ?",
            arrayOf(currentUserId.toString())
        ).use { c ->
            if (c.moveToFirst()) User(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
            else User("", "", "", "B+", "")
        }

    /** Creates an account and logs it in. Returns false if the email or phone is already used. */
    fun register(fullName: String, phone: String, email: String, password: String): Boolean {
        val values = ContentValues().apply {
            put("full_name", fullName)
            put("phone", phone)
            put("phone_digits", phoneDigits(phone))
            put("email", email)
            put("blood_group", "B+")
            put("location", "")
            put("password_hash", sha256(password))
        }
        return try {
            val id = wdb.insertOrThrow("users", null, values)
            prefs.edit().putLong(KEY_USER, id).apply()
            true
        } catch (e: SQLiteConstraintException) {
            false
        }
    }

    private fun findUserId(identifier: String): Long? {
        val id = identifier.trim()
        if (id.isEmpty()) return null
        val where: String
        val arg: String
        if (id.contains("@")) {
            where = "email = ? COLLATE NOCASE"
            arg = id
        } else {
            val d = phoneDigits(id)
            if (d.length < 10) return null
            where = "phone_digits = ?"
            arg = d
        }
        return rdb.rawQuery("SELECT id FROM users WHERE $where", arrayOf(arg)).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        }
    }

    /** Logs in with email or phone + password. */
    fun login(identifier: String, password: String): Boolean {
        val uid = findUserId(identifier) ?: return false
        val ok = rdb.rawQuery("SELECT password_hash FROM users WHERE id = ?", arrayOf(uid.toString())).use { c ->
            c.moveToFirst() && c.getString(0) == sha256(password)
        }
        if (ok) prefs.edit().putLong(KEY_USER, uid).apply()
        return ok
    }

    /** Updates the logged-in user's profile. Returns false if the email/phone belongs to someone else. */
    fun updateUser(user: User): Boolean {
        val values = ContentValues().apply {
            put("full_name", user.fullName)
            put("phone", user.phone)
            put("phone_digits", phoneDigits(user.phone))
            put("email", user.email)
            put("blood_group", user.bloodGroup)
            put("location", user.location)
        }
        return try {
            wdb.update("users", values, "id = ?", arrayOf(currentUserId.toString())) > 0
        } catch (e: SQLiteConstraintException) {
            false
        }
    }

    fun checkPassword(password: String): Boolean =
        rdb.rawQuery("SELECT password_hash FROM users WHERE id = ?", arrayOf(currentUserId.toString())).use { c ->
            c.moveToFirst() && c.getString(0) == sha256(password)
        }

    fun setPassword(password: String) {
        wdb.update(
            "users", ContentValues().apply { put("password_hash", sha256(password)) },
            "id = ?", arrayOf(currentUserId.toString())
        )
    }

    /** Forgot-password: sets a new password for the account with this email/phone. */
    fun resetPassword(identifier: String, newPassword: String): Boolean {
        val uid = findUserId(identifier) ?: return false
        return wdb.update(
            "users", ContentValues().apply { put("password_hash", sha256(newPassword)) },
            "id = ?", arrayOf(uid.toString())
        ) > 0
    }

    // ------------------------------------------------------- notification toggles
    fun getNotif(key: String, default: Boolean) = prefs.getBoolean("n_$key", default)
    fun setNotif(key: String, value: Boolean) = prefs.edit().putBoolean("n_$key", value).apply()

    // ----------------------------------------------------------------- requests
    private fun Cursor.toRequest() = BloodRequest(
        id = getString(getColumnIndexOrThrow("id")),
        date = getString(getColumnIndexOrThrow("request_date")),
        bloodGroup = getString(getColumnIndexOrThrow("blood_group")),
        units = getString(getColumnIndexOrThrow("units")),
        hospital = getString(getColumnIndexOrThrow("hospital")),
        reason = getString(getColumnIndexOrThrow("reason")),
        status = getString(getColumnIndexOrThrow("status"))
    )

    fun createRequest(bloodGroup: String, units: String, hospital: String, reason: String): BloodRequest {
        val date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        for (attempt in 1..5) {
            val id = "#BR" + (100000 + Random.nextInt(900000))
            val values = ContentValues().apply {
                put("id", id)
                put("user_id", currentUserId)
                put("request_date", date)
                put("blood_group", bloodGroup)
                put("units", units)
                put("hospital", hospital)
                put("reason", reason)
                put("status", STATUS_PENDING)
                put("created_at", System.currentTimeMillis())
            }
            try {
                wdb.insertOrThrow("requests", null, values)
                return BloodRequest(id, date, bloodGroup, units, hospital, reason, STATUS_PENDING)
            } catch (e: SQLiteConstraintException) {
                if (attempt == 5) throw e // id clash is very unlikely; otherwise try another id
            }
        }
        throw IllegalStateException("Could not create request")
    }

    fun getRequest(id: String): BloodRequest? =
        rdb.rawQuery("SELECT * FROM requests WHERE id = ?", arrayOf(id)).use { c ->
            if (c.moveToFirst()) c.toRequest() else null
        }

    fun lastRequest(): BloodRequest? =
        rdb.rawQuery(
            "SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
            arrayOf(currentUserId.toString())
        ).use { c -> if (c.moveToFirst()) c.toRequest() else null }

    // ------------------------------------------------------------------- donors
    private fun Cursor.toDonor() = Donor(
        id = getInt(getColumnIndexOrThrow("id")),
        name = getString(getColumnIndexOrThrow("name")),
        bloodGroup = getString(getColumnIndexOrThrow("blood_group")),
        gender = getString(getColumnIndexOrThrow("gender")),
        age = getInt(getColumnIndexOrThrow("age")),
        distanceKm = getInt(getColumnIndexOrThrow("distance_km")),
        city = getString(getColumnIndexOrThrow("city")),
        phone = getString(getColumnIndexOrThrow("phone")),
        email = getString(getColumnIndexOrThrow("email")),
        lastDonation = getString(getColumnIndexOrThrow("last_donation")),
        available = getInt(getColumnIndexOrThrow("available")) == 1,
        mapX = getFloat(getColumnIndexOrThrow("map_x")),
        mapY = getFloat(getColumnIndexOrThrow("map_y")),
        bankId = getColumnIndex("bank_id").let { if (it >= 0 && !isNull(it)) getInt(it) else 0 },
        bankName = getColumnIndex("bank_name").let { if (it >= 0 && !isNull(it)) getString(it) else "" },
        userId = getColumnIndex("user_id").let { if (it >= 0 && !isNull(it)) getLong(it) else 0L }
    )

    private const val DONOR_SELECT =
        "SELECT d.*, b.name AS bank_name FROM donors d LEFT JOIN blood_banks b ON b.id = d.bank_id "

    private fun queryDonors(where: String, args: Array<String>): List<Donor> =
        rdb.rawQuery(DONOR_SELECT + where + " ORDER BY d.distance_km", args).use { c ->
            val list = ArrayList<Donor>()
            while (c.moveToNext()) list.add(c.toDonor())
            list
        }

    /** Donors a normal user can search (their own donor record is left out). */
    val donors: List<Donor>
        get() = queryDonors("WHERE d.user_id IS NULL OR d.user_id <> ?", arrayOf(currentUserId.toString()))

    /** Every donor in the city (admin views). */
    fun allDonors(): List<Donor> = queryDonors("", emptyArray())

    /** Donors registered with one blood bank. */
    fun donorsOfBank(bankId: Long): List<Donor> = queryDonors("WHERE d.bank_id = ?", arrayOf(bankId.toString()))

    fun donorById(id: Int): Donor? =
        rdb.rawQuery(DONOR_SELECT + "WHERE d.id = ?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) c.toDonor() else null
        }

    /** The donor profile of the logged-in account, if it has registered as a donor. */
    fun myDonor(): Donor? = queryDonors("WHERE d.user_id = ?", arrayOf(currentUserId.toString())).firstOrNull()

    fun hasDonorProfile(): Boolean = myDonor() != null

    // ---------------------------------------------------------------- donations
    val donations: List<Donation>
        get() = rdb.rawQuery(
            "SELECT donated_on, blood_group, units FROM donations WHERE user_id = ? ORDER BY id",
            arrayOf(currentUserId.toString())
        ).use { c ->
            val list = ArrayList<Donation>()
            while (c.moveToNext()) list.add(Donation(c.getString(0), c.getString(1), c.getInt(2)))
            list
        }

    fun addDonation(date: String, bloodGroup: String, units: Int) {
        wdb.insert("donations", null, ContentValues().apply {
            put("user_id", currentUserId)
            put("donated_on", date)
            put("blood_group", bloodGroup)
            put("units", units)
        })
    }

    // ------------------------------------------------------------------- roles
    const val ROLE_DONOR = 0
    const val ROLE_BANK_ADMIN = 1
    const val ROLE_SUPER_ADMIN = 2

    /** 0 = donor / normal user, 1 = blood bank admin, 2 = super admin. */
    fun getRole(): Int =
        rdb.rawQuery("SELECT role FROM users WHERE id = ?", arrayOf(currentUserId.toString())).use { c ->
            if (c.moveToFirst()) c.getInt(0) else ROLE_DONOR
        }

    fun isAdmin(): Boolean = getRole() >= ROLE_BANK_ADMIN
    fun isSuperAdmin(): Boolean = getRole() == ROLE_SUPER_ADMIN
    fun isBankAdmin(): Boolean = getRole() == ROLE_BANK_ADMIN

    /** The bank a bank admin manages (0 if none). */
    fun myBankId(): Long =
        rdb.rawQuery("SELECT bank_id FROM users WHERE id = ?", arrayOf(currentUserId.toString())).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
        }

    /** True when the account is an admin AND also a registered donor ("both" account). */
    fun isBothRoles(): Boolean = isAdmin() && hasDonorProfile()

    /** For admin accounts: true = Admin Dashboard is the current view, false = donor Home. */
    var adminMode: Boolean
        get() = prefs.getBoolean("admin_mode", false)
        set(value) = prefs.edit().putBoolean("admin_mode", value).apply()

    fun getStats(): AdminStats = AdminStats(
        users = DatabaseUtils.queryNumEntries(rdb, "users", "role = 0").toInt(),
        donors = DatabaseUtils.queryNumEntries(rdb, "donors").toInt(),
        requests = DatabaseUtils.queryNumEntries(rdb, "requests").toInt(),
        pending = DatabaseUtils.queryNumEntries(rdb, "requests", "status = ?", arrayOf(STATUS_PENDING)).toInt()
    )

    fun allUsers(): List<UserRow> =
        rdb.rawQuery(
            "SELECT u.id, u.full_name, u.email, u.phone, u.blood_group, u.role, IFNULL(b.name, '') " +
                "FROM users u LEFT JOIN blood_banks b ON b.id = u.bank_id ORDER BY u.role DESC, u.id",
            null
        ).use { c ->
            val list = ArrayList<UserRow>()
            while (c.moveToNext()) {
                list.add(UserRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getInt(5), c.getString(6)))
            }
            list
        }

    /** Deletes a normal user (and, through the foreign keys, their requests and donations). */
    fun deleteUser(id: Long): Boolean =
        wdb.delete("users", "id = ? AND role = 0", arrayOf(id.toString())) > 0

    fun allRequests(): List<AdminRequest> =
        rdb.rawQuery(
            "SELECT r.*, u.full_name AS requester FROM requests r " +
                "JOIN users u ON u.id = r.user_id ORDER BY r.created_at DESC",
            null
        ).use { c ->
            val list = ArrayList<AdminRequest>()
            while (c.moveToNext()) {
                list.add(AdminRequest(c.toRequest(), c.getString(c.getColumnIndexOrThrow("requester"))))
            }
            list
        }

    fun updateRequestStatus(id: String, status: String) {
        wdb.update("requests", ContentValues().apply { put("status", status) }, "id = ?", arrayOf(id))
    }

    /** Adds a donor (id == 0) or updates an existing one. */
    fun saveDonor(d: Donor): Boolean {
        val v = ContentValues().apply {
            put("name", d.name)
            put("blood_group", d.bloodGroup)
            put("gender", d.gender)
            put("age", d.age)
            put("distance_km", d.distanceKm)
            put("city", d.city)
            put("phone", d.phone)
            put("email", d.email)
            put("last_donation", d.lastDonation)
            put("available", if (d.available) 1 else 0)
            if (d.bankId > 0) put("bank_id", d.bankId) else putNull("bank_id")
            if (d.userId > 0) put("user_id", d.userId) else putNull("user_id")
        }
        return if (d.id == 0) {
            v.put("map_x", d.mapX)
            v.put("map_y", d.mapY)
            wdb.insert("donors", null, v) != -1L
        } else {
            wdb.update("donors", v, "id = ?", arrayOf(d.id.toString())) > 0
        }
    }

    fun deleteDonor(id: Int): Boolean = wdb.delete("donors", "id = ?", arrayOf(id.toString())) > 0

    const val STATUS_PENDING = "Looking for donors"
    const val STATUS_FULFILLED = "Fulfilled"
    const val STATUS_CANCELLED = "Cancelled"
}
