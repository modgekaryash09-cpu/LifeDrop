package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var b: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        b.rowEditProfile.setOnClickListener { openScreen<EditProfileActivity>() }
        b.rowChangePassword.setOnClickListener { showChangePasswordDialog() }
        b.rowNotifications.setOnClickListener { openScreen<NotificationSettingsActivity>() }
        b.rowAbout.setOnClickListener { openScreen<AboutActivity>() }
        b.rowLogout.setOnClickListener { confirmLogout() }
    }

    override fun onResume() {
        super.onResume()
        val u = AppStore.getUser()
        b.tvName.text = u.fullName
        b.tvEmail.text = u.email
        b.tvPhone.text = u.phone
    }
}
