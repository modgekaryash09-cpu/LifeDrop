package com.blooddonor.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.blooddonor.app.R
import com.blooddonor.app.data.AdminRequest
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.Donor
import com.blooddonor.app.data.UserRow
import com.blooddonor.app.databinding.ItemAdminDonorBinding
import com.blooddonor.app.databinding.ItemAdminRequestBinding
import com.blooddonor.app.databinding.ItemAdminUserBinding

class AdminDonorAdapter(
    private val onEdit: (Donor) -> Unit,
    private val onDelete: (Donor) -> Unit
) : ListAdapter<Donor, AdminDonorAdapter.VH>(Diff) {

    class VH(val b: ItemAdminDonorBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAdminDonorBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = getItem(position)
        val ctx = holder.b.root.context
        holder.b.tvName.text = d.name
        holder.b.tvInfo.text = "${d.bloodGroup}  |  ${d.gender}  |  ${d.age} yrs  |  ${d.distanceKm} km" +
            (if (d.bankName.isEmpty()) "" else "\n${d.bankName}")
        if (d.available) {
            holder.b.tvStatus.text = "Available"
            holder.b.tvStatus.setTextColor(ctx.getColor(R.color.green))
            holder.b.tvStatus.setBackgroundResource(R.drawable.bg_badge)
        } else {
            holder.b.tvStatus.text = "Unavailable"
            holder.b.tvStatus.setTextColor(ctx.getColor(R.color.muted))
            holder.b.tvStatus.setBackgroundResource(R.drawable.bg_badge_off)
        }
        holder.b.root.setOnClickListener { onEdit(d) }
        holder.b.btnDelete.setOnClickListener { onDelete(d) }
    }

    object Diff : DiffUtil.ItemCallback<Donor>() {
        override fun areItemsTheSame(a: Donor, b: Donor) = a.id == b.id
        override fun areContentsTheSame(a: Donor, b: Donor) = a == b
    }
}

class AdminUserAdapter(
    private val onDelete: (UserRow) -> Unit
) : ListAdapter<UserRow, AdminUserAdapter.VH>(Diff) {

    class VH(val b: ItemAdminUserBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAdminUserBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val u = getItem(position)
        holder.b.tvName.text = u.fullName
        holder.b.tvEmail.text = u.email
        holder.b.tvInfo.text = "${u.phone}  |  ${u.bloodGroup}"
        holder.b.tvRole.text = u.roleLabel
        holder.b.tvRole.visibility = if (u.isAdmin) View.VISIBLE else View.GONE
        // Accounts with admin rights cannot be deleted from the app.
        holder.b.btnDelete.visibility = if (u.isAdmin) View.GONE else View.VISIBLE
        holder.b.btnDelete.setOnClickListener { onDelete(u) }
    }

    object Diff : DiffUtil.ItemCallback<UserRow>() {
        override fun areItemsTheSame(a: UserRow, b: UserRow) = a.id == b.id
        override fun areContentsTheSame(a: UserRow, b: UserRow) = a == b
    }
}

class AdminRequestAdapter(
    private val onStatus: (AdminRequest, String) -> Unit
) : ListAdapter<AdminRequest, AdminRequestAdapter.VH>(Diff) {

    class VH(val b: ItemAdminRequestBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAdminRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        val r = item.request
        val ctx = holder.b.root.context
        holder.b.tvRequestId.text = r.id
        holder.b.tvRequester.text = "Requested by ${item.requesterName}"
        holder.b.tvDetails.text = "${r.bloodGroup}  |  ${r.units}  |  ${r.hospital}"
        holder.b.tvDate.text = r.date
        styleStatus(holder.b.tvStatus, r.status, ctx.getColor(R.color.green), ctx.getColor(R.color.muted), ctx.getColor(R.color.orange))
        holder.b.btnFulfilled.isEnabled = !r.status.startsWith(AppStore.STATUS_FULFILLED)
        holder.b.btnCancel.isEnabled = r.status != AppStore.STATUS_CANCELLED
        holder.b.btnFulfilled.setOnClickListener { onStatus(item, AppStore.STATUS_FULFILLED) }
        holder.b.btnCancel.setOnClickListener { onStatus(item, AppStore.STATUS_CANCELLED) }
    }

    private fun styleStatus(view: TextView, status: String, green: Int, grey: Int, orange: Int) {
        view.text = status
        when {
            status.startsWith(AppStore.STATUS_FULFILLED) -> {
                view.setTextColor(green)
                view.setBackgroundResource(R.drawable.bg_badge)
            }
            status == AppStore.STATUS_CANCELLED -> {
                view.setTextColor(grey)
                view.setBackgroundResource(R.drawable.bg_badge_off)
            }
            else -> {
                view.setTextColor(orange)
                view.setBackgroundResource(R.drawable.bg_pinkbox)
            }
        }
    }

    object Diff : DiffUtil.ItemCallback<AdminRequest>() {
        override fun areItemsTheSame(a: AdminRequest, b: AdminRequest) = a.request.id == b.request.id
        override fun areContentsTheSame(a: AdminRequest, b: AdminRequest) = a == b
    }
}
