package com.blooddonor.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.blooddonor.app.data.AppStore
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun Context.toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

fun Context.dial(phone: String) {
    val number = phone.filter { it.isDigit() || it == '+' }
    try {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    } catch (e: ActivityNotFoundException) {
        toast("No dialer app found")
    }
}

inline fun <reified T : Activity> Context.openScreen(configure: Intent.() -> Unit = {}) {
    startActivity(Intent(this, T::class.java).apply(configure))
}

/** Opens the Login screen with a fresh back stack (used after logout). */
fun Context.restartAtLogin() {
    startActivity(Intent(this, LoginActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
    })
}

fun Activity.goBack(view: android.view.View) {
    view.setOnClickListener { finish() }
}

/** Opens Home and clears everything above it. */
fun Context.openHomeFresh() {
    startActivity(Intent(this, HomeActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
    })
}

/** Opens the Admin Dashboard and clears everything above it. */
fun Context.openAdminFresh() {
    startActivity(Intent(this, AdminDashboardActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
    })
}

/** Opens the right first screen for the logged-in account (donor, admin, or both). */
fun Activity.routeAfterLogin() {
    when {
        !AppStore.isAdmin() -> {
            AppStore.adminMode = false
            openHomeFresh()
        }
        AppStore.hasDonorProfile() -> {
            // "Both" account: admin and donor. Let the person choose.
            MaterialAlertDialogBuilder(this)
                .setTitle("Continue as")
                .setCancelable(false)
                .setItems(arrayOf("Admin Dashboard", "Donor Home")) { _, which ->
                    AppStore.adminMode = which == 0
                    if (which == 0) openAdminFresh() else openHomeFresh()
                }
                .show()
        }
        else -> {
            AppStore.adminMode = true
            openAdminFresh()
        }
    }
}
