package com.blooddonor.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityRequestStatusBinding

class RequestStatusActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityRequestStatusBinding.inflate(layoutInflater)
        setContentView(b.root)

        val request = intent.getStringExtra(EXTRA_REQUEST_ID)?.let { AppStore.getRequest(it) }
        if (request == null) {
            toast("Request not found")
            finish()
            return
        }
        b.tvMessage.text = "Your request for ${request.bloodGroup} blood has been\nsuccessfully submitted."
        b.tvRequestId.text = request.id
        b.tvDate.text = request.date
        b.tvStatus.text = (if (request.status.startsWith("Fulfilled")) "✅ " else "⏳ ") + request.status

        b.btnBack.setOnClickListener { goHome() }
        b.btnBackHome.setOnClickListener { goHome() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
    }

    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
        finish()
    }

    companion object {
        const val EXTRA_REQUEST_ID = "request_id"
    }
}
