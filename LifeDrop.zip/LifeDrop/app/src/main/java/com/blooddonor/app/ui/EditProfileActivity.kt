package com.blooddonor.app.ui

import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.User
import com.blooddonor.app.databinding.ActivityEditProfileBinding

class EditProfileActivity : AppCompatActivity() {
    private lateinit var b: ActivityEditProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        val u = AppStore.getUser()
        b.etFullName.setText(u.fullName)
        b.etPhone.setText(u.phone)
        b.etEmail.setText(u.email)
        b.etLocation.setText(u.location)
        val index = resources.getStringArray(R.array.blood_groups).indexOf(u.bloodGroup)
        if (index >= 0) b.spBloodGroup.setSelection(index)

        b.btnSaveChanges.setOnClickListener { save() }
    }

    private fun save() {
        b.tilEtFullName.error = null
        b.tilEtPhone.error = null
        b.tilEtEmail.error = null

        val name = b.etFullName.text.toString().trim()
        val phone = b.etPhone.text.toString().trim()
        val email = b.etEmail.text.toString().trim()

        var valid = true
        if (name.length < 2) {
            b.tilEtFullName.error = "Enter your full name"; valid = false
        }
        if (phone.filter { it.isDigit() }.length < 10) {
            b.tilEtPhone.error = "Enter a valid phone number"; valid = false
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            b.tilEtEmail.error = "Enter a valid email"; valid = false
        }
        if (!valid) return

        val saved = AppStore.updateUser(
            User(
                fullName = name,
                phone = phone,
                email = email,
                bloodGroup = b.spBloodGroup.selectedItem.toString(),
                location = b.etLocation.text.toString().trim()
            )
        )
        if (!saved) {
            b.tilEtEmail.error = "This email or phone is already used by another account"
            return
        }
        toast("Profile updated")
        finish()
    }
}
