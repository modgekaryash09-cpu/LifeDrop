package com.blooddonor.app.ui

import android.app.Activity
import android.text.InputType
import android.util.Patterns
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.blooddonor.app.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

enum class FieldType { TEXT, NUMBER, PHONE, EMAIL, PASSWORD, CHOICE }

class Field(
    val key: String,
    val hint: String,
    val type: FieldType = FieldType.TEXT,
    val options: List<String> = emptyList(),
    val initial: String = ""
)

/**
 * Builds a simple form dialog from a list of fields (no extra layout files needed).
 * [onSubmit] gets the values by key and returns an error message, or null to close the dialog.
 */
fun Activity.showForm(
    title: String,
    fields: List<Field>,
    positive: String = "Save",
    onSubmit: (Map<String, String>) -> String?
) {
    val dp = resources.displayMetrics.density
    val pad = (16 * dp).toInt()
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad / 2, pad, 0)
    }
    val inputs = LinkedHashMap<String, TextInputLayout>()
    val spinners = LinkedHashMap<String, Spinner>()

    fields.forEach { f ->
        if (f.type == FieldType.CHOICE) {
            box.addView(TextView(this).apply {
                text = f.hint
                textSize = 12f
                setTextColor(getColor(R.color.muted))
                setPadding(0, (10 * dp).toInt(), 0, (4 * dp).toInt())
            })
            val sp = Spinner(this).apply {
                adapter = ArrayAdapter(this@showForm, android.R.layout.simple_spinner_dropdown_item, f.options)
                setBackgroundResource(R.drawable.bg_spinner)
                val i = f.options.indexOf(f.initial)
                if (i >= 0) setSelection(i)
            }
            spinners[f.key] = sp
            box.addView(sp, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (48 * dp).toInt()))
        } else {
            val til = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle)
            til.hint = f.hint
            val et = TextInputEditText(til.context)
            et.inputType = when (f.type) {
                FieldType.NUMBER -> InputType.TYPE_CLASS_NUMBER
                FieldType.PHONE -> InputType.TYPE_CLASS_PHONE
                FieldType.EMAIL -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                FieldType.PASSWORD -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            }
            et.setText(f.initial)
            til.addView(et)
            inputs[f.key] = til
            box.addView(til, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * dp).toInt() })
        }
    }

    val dialog = MaterialAlertDialogBuilder(this)
        .setTitle(title)
        .setView(ScrollView(this).apply { addView(box) })
        .setPositiveButton(positive, null)
        .setNegativeButton("Cancel", null)
        .create()
    dialog.show()

    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
        var ok = true
        val values = LinkedHashMap<String, String>()
        fields.forEach { f ->
            if (f.type == FieldType.CHOICE) {
                values[f.key] = spinners[f.key]?.selectedItem?.toString() ?: ""
            } else {
                val til = inputs.getValue(f.key)
                val v = til.editText?.text?.toString()?.trim() ?: ""
                til.error = null
                val err = when {
                    v.isEmpty() -> "Required"
                    f.type == FieldType.EMAIL && !Patterns.EMAIL_ADDRESS.matcher(v).matches() -> "Enter a valid email"
                    f.type == FieldType.PHONE && v.count { it.isDigit() } < 10 -> "Enter a valid phone number"
                    f.type == FieldType.NUMBER && v.toIntOrNull() == null -> "Enter a number"
                    f.type == FieldType.PASSWORD && v.length < 6 -> "At least 6 characters"
                    else -> null
                }
                if (err != null) { til.error = err; ok = false }
                values[f.key] = v
            }
        }
        if (!ok) return@setOnClickListener
        val error = onSubmit(values)
        if (error != null) toast(error) else dialog.dismiss()
    }
}
