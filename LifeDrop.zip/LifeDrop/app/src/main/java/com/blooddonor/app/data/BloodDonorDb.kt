package com.blooddonor.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

internal fun sha256(text: String): String =
    MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }

/** Last 10 digits of a phone number, used to look accounts up. */
internal fun phoneDigits(text: String): String = text.filter { it.isDigit() }.takeLast(10)

/**
 * SQLite database for the app.
 * Tables: users, donors, donations, requests, blood_banks, blood_stock, donation_requests.
 * Roles (users.role): 0 = donor / normal user, 1 = blood bank admin, 2 = super admin.
 * A bank admin or super admin who also has a donor profile is a "both" account.
 */
class BloodDonorDb(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                phone_digits TEXT NOT NULL UNIQUE,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                blood_group TEXT NOT NULL DEFAULT 'B+',
                location TEXT NOT NULL DEFAULT '',
                password_hash TEXT NOT NULL,
                is_admin INTEGER NOT NULL DEFAULT 0,
                role INTEGER NOT NULL DEFAULT 0,
                bank_id INTEGER
            )"""
        )
        db.execSQL(
            """CREATE TABLE donors (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                blood_group TEXT NOT NULL,
                gender TEXT NOT NULL,
                age INTEGER NOT NULL,
                distance_km INTEGER NOT NULL,
                city TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT NOT NULL,
                last_donation TEXT NOT NULL,
                available INTEGER NOT NULL DEFAULT 1,
                map_x REAL NOT NULL,
                map_y REAL NOT NULL,
                bank_id INTEGER,
                user_id INTEGER
            )"""
        )
        db.execSQL(
            """CREATE TABLE donations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                donated_on TEXT NOT NULL,
                blood_group TEXT NOT NULL,
                units INTEGER NOT NULL DEFAULT 1
            )"""
        )
        db.execSQL(
            """CREATE TABLE requests (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                request_date TEXT NOT NULL,
                blood_group TEXT NOT NULL,
                units TEXT NOT NULL,
                hospital TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )"""
        )
        createBankTables(db)

        val demo = ContentValues().apply {
            put("full_name", "Yash Modgekar")
            put("phone", "+91 98765 43210")
            put("phone_digits", phoneDigits("+91 98765 43210"))
            put("email", "yash@example.com")
            put("blood_group", "B+")
            put("location", "Pune, Maharashtra")
            put("password_hash", sha256("123456"))
        }
        val userId = db.insert("users", null, demo)

        listOf(
            Triple("25 Aug 2026", "B+", 1),
            Triple("12 Feb 2026", "O+", 1),
            Triple("03 Oct 2025", "A+", 1),
            Triple("15 Jun 2025", "B-", 1)
        ).forEach { (date, group, units) ->
            db.insert("donations", null, ContentValues().apply {
                put("user_id", userId)
                put("donated_on", date)
                put("blood_group", group)
                put("units", units)
            })
        }

        SEED_DONORS.forEach { d ->
            db.insert("donors", null, ContentValues().apply {
                put("id", d.id)
                put("name", d.name)
                put("blood_group", d.bloodGroup)
                put("gender", d.gender)
                put("age", d.age)
                put("distance_km", d.distanceKm)
                put("city", d.city)
                put("phone", d.phone)
                put("email", d.email)
                put("last_donation", d.lastDonation)
                put("available", if (d.available) 1 else 0)
                put("map_x", d.mapX)
                put("map_y", d.mapY)
            })
        }
        seedRoles(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 3) {
            // Version 3: three roles + multiple blood banks. Existing data is kept.
            db.execSQL("ALTER TABLE users ADD COLUMN role INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE users ADD COLUMN bank_id INTEGER")
            db.execSQL("ALTER TABLE donors ADD COLUMN bank_id INTEGER")
            db.execSQL("ALTER TABLE donors ADD COLUMN user_id INTEGER")
            db.execSQL("UPDATE users SET role = 2 WHERE is_admin = 1") // old admin = super admin
            createBankTables(db)
            seedRoles(db)
        }
    }

    private fun createBankTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE blood_banks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                city TEXT NOT NULL DEFAULT 'Pune',
                address TEXT NOT NULL DEFAULT '',
                phone TEXT NOT NULL DEFAULT '',
                email TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'APPROVED',
                applicant_user_id INTEGER,
                distance_km INTEGER NOT NULL DEFAULT 5,
                created_at INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE blood_stock (
                bank_id INTEGER NOT NULL REFERENCES blood_banks(id) ON DELETE CASCADE,
                blood_group TEXT NOT NULL,
                units INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (bank_id, blood_group)
            )"""
        )
        db.execSQL(
            """CREATE TABLE donation_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                bank_id INTEGER NOT NULL REFERENCES blood_banks(id) ON DELETE CASCADE,
                blood_group TEXT NOT NULL,
                units INTEGER NOT NULL DEFAULT 1,
                preferred_date TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pending',
                created_at INTEGER NOT NULL
            )"""
        )
    }

    /** Inserts a staff account; does nothing if the email/phone already exists. */
    private fun insertStaff(
        db: SQLiteDatabase, fullName: String, phone: String, email: String,
        password: String, role: Int, bankId: Long?
    ) {
        val staff = ContentValues().apply {
            put("full_name", fullName)
            put("phone", phone)
            put("phone_digits", phoneDigits(phone))
            put("email", email)
            put("blood_group", "O+")
            put("location", "Pune, Maharashtra")
            put("password_hash", sha256(password))
            put("role", role)
            if (bankId != null) put("bank_id", bankId)
        }
        db.insertWithOnConflict("users", null, staff, SQLiteDatabase.CONFLICT_IGNORE)
    }

    private fun scalarLong(db: SQLiteDatabase, sql: String, vararg args: String): Long =
        db.rawQuery(sql, args).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L }

    /** Seeds banks, stock, staff accounts and donor links. Safe to run on an existing database. */
    private fun seedRoles(db: SQLiteDatabase) {
        insertStaff(db, "LifeDrop Super Admin", "+91 90000 00000", ADMIN_EMAIL, ADMIN_PASSWORD, 2, null)

        if (scalarLong(db, "SELECT COUNT(*) FROM blood_banks") == 0L) {
            val now = System.currentTimeMillis()
            SEED_BANKS.forEachIndexed { i, b ->
                val bankId = db.insert("blood_banks", null, ContentValues().apply {
                    put("name", b.name)
                    put("city", "Pune")
                    put("address", b.address)
                    put("phone", b.phone)
                    put("email", b.email)
                    put("status", b.status)
                    put("distance_km", b.distance)
                    put("created_at", now + i)
                })
                BLOOD_GROUPS.forEachIndexed { g, group ->
                    db.insert("blood_stock", null, ContentValues().apply {
                        put("bank_id", bankId)
                        put("blood_group", group)
                        put("units", ((i + 2) * (g + 3)) % 17 + 1)
                    })
                }
            }
        }

        val cityBank = scalarLong(db, "SELECT id FROM blood_banks WHERE name = ?", "City Blood Bank")
        val redCross = scalarLong(db, "SELECT id FROM blood_banks WHERE name = ?", "Red Cross Blood Bank")
        val sahyadri = scalarLong(db, "SELECT id FROM blood_banks WHERE name = ?", "Sahyadri Blood Bank")
        if (cityBank > 0) insertStaff(db, "City Bank Admin", "+91 90000 00010", "citybank@lifedrop.app", BANK_PASSWORD, 1, cityBank)
        if (redCross > 0) insertStaff(db, "Red Cross Admin", "+91 90000 00011", "redcross@lifedrop.app", BANK_PASSWORD, 1, redCross)
        if (sahyadri > 0) insertStaff(db, "Sahyadri Manager", "+91 90000 00012", MANAGER_EMAIL, MANAGER_PASSWORD, 1, sahyadri)

        // Donors that are not linked to a bank yet are shared out between the approved banks.
        val bankIds = ArrayList<Long>()
        db.rawQuery("SELECT id FROM blood_banks WHERE status = 'APPROVED' ORDER BY id", null).use { c ->
            while (c.moveToNext()) bankIds.add(c.getLong(0))
        }
        if (bankIds.isNotEmpty()) {
            val ids = ArrayList<Long>()
            db.rawQuery("SELECT id FROM donors WHERE bank_id IS NULL ORDER BY id", null).use { c ->
                while (c.moveToNext()) ids.add(c.getLong(0))
            }
            ids.forEachIndexed { i, donorId ->
                db.execSQL("UPDATE donors SET bank_id = ? WHERE id = ?", arrayOf(bankIds[i % bankIds.size], donorId))
            }
        }

        // The manager is a bank admin AND a registered donor ("both" account).
        val managerId = scalarLong(db, "SELECT id FROM users WHERE email = ? COLLATE NOCASE", MANAGER_EMAIL)
        if (managerId > 0 && sahyadri > 0 &&
            scalarLong(db, "SELECT COUNT(*) FROM donors WHERE user_id = ?", managerId.toString()) == 0L
        ) {
            db.insert("donors", null, ContentValues().apply {
                put("name", "Sahyadri Manager")
                put("blood_group", "O+")
                put("gender", "Male")
                put("age", 35)
                put("distance_km", 9)
                put("city", "Pune, Maharashtra")
                put("phone", "+91 90000 00012")
                put("email", MANAGER_EMAIL)
                put("last_donation", "Never")
                put("available", 1)
                put("map_x", 0.5f)
                put("map_y", 0.5f)
                put("bank_id", sahyadri)
                put("user_id", managerId)
            })
        }
    }

    private class SeedBank(
        val name: String, val address: String, val phone: String, val email: String,
        val distance: Int, val status: String
    )

    companion object {
        const val DB_NAME = "blooddonor.db"
        const val DB_VERSION = 3
        const val ADMIN_EMAIL = "admin@lifedrop.app"
        const val ADMIN_PASSWORD = "admin123"
        const val MANAGER_EMAIL = "manager@lifedrop.app"
        const val MANAGER_PASSWORD = "manager123"
        const val BANK_PASSWORD = "bank123"

        val BLOOD_GROUPS = listOf("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")

        private val SEED_BANKS = listOf(
            SeedBank("City Blood Bank", "Shivajinagar, Pune", "+91 20 2553 0001", "city@bank.example", 4, "APPROVED"),
            SeedBank("Red Cross Blood Bank", "Sadashiv Peth, Pune", "+91 20 2446 0002", "redcross@bank.example", 7, "APPROVED"),
            SeedBank("Sahyadri Blood Bank", "Deccan Gymkhana, Pune", "+91 20 2567 0003", "sahyadri@bank.example", 9, "APPROVED"),
            SeedBank("Lifeline Blood Centre", "Kothrud, Pune", "+91 20 2538 0004", "lifeline@bank.example", 12, "PENDING")
        )

        private val SEED_DONORS = listOf(
            Donor(1, "Rahul Sharma", "B+", "Male", 22, 22, "Pune, Maharashtra", "+91 98765 43210", "rahul@example.com", "6 months ago", true, 0.30f, 0.20f),
            Donor(2, "Sneha Patel", "O+", "Female", 25, 15, "Pune, Maharashtra", "+91 98123 45678", "sneha@example.com", "4 months ago", true, 0.65f, 0.15f),
            Donor(3, "Amit Verma", "A-", "Male", 30, 8, "Pune, Maharashtra", "+91 97654 32109", "amit@example.com", "8 months ago", true, 0.20f, 0.40f),
            Donor(4, "Priya Singh", "B+", "Female", 27, 12, "Pune, Maharashtra", "+91 99887 76655", "priya@example.com", "5 months ago", true, 0.80f, 0.35f),
            Donor(5, "Vikram Joshi", "O-", "Male", 34, 18, "Pune, Maharashtra", "+91 91234 56780", "vikram@example.com", "7 months ago", true, 0.45f, 0.65f),
            Donor(6, "Anjali Desai", "A+", "Female", 29, 5, "Pune, Maharashtra", "+91 90909 12345", "anjali@example.com", "9 months ago", false, 0.75f, 0.70f),
            Donor(7, "Rohan Kulkarni", "AB+", "Male", 31, 11, "Pune, Maharashtra", "+91 98220 11223", "rohan@example.com", "3 months ago", true, 0.12f, 0.70f),
            Donor(8, "Neha Gupta", "B-", "Female", 24, 20, "Pune, Maharashtra", "+91 98500 44556", "neha@example.com", "10 months ago", true, 0.55f, 0.88f)
        )
    }
}
