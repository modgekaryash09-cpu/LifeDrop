package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged
import androidx.recyclerview.widget.DividerItemDecoration
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityFindDonorsBinding
import com.google.android.material.chip.Chip

class FindDonorsActivity : AppCompatActivity() {
    private lateinit var b: ActivityFindDonorsBinding
    private lateinit var adapter: DonorAdapter
    private var query = ""
    private var group = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFindDonorsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.btnMap.setOnClickListener { openScreen<NearbyDonorsActivity>() }

        adapter = DonorAdapter(
            onItemClick = { d ->
                openScreen<DonorProfileActivity> { putExtra(DonorProfileActivity.EXTRA_DONOR_ID, d.id) }
            },
            onCallClick = { d -> dial(d.phone) }
        )
        b.rvDonors.adapter = adapter
        b.rvDonors.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))

        b.etSearch.doOnTextChanged { text, _, _, _ ->
            query = text?.toString()?.trim().orEmpty()
            applyFilter()
        }
        b.chipGroupBlood.setOnCheckedStateChangeListener { chipGroup, checkedIds ->
            val chip = checkedIds.firstOrNull()?.let { chipGroup.findViewById<Chip>(it) }
            group = chip?.text?.toString() ?: "All"
            applyFilter()
        }
        applyFilter()
    }

    private fun applyFilter() {
        val result = AppStore.donors
            .filter { group == "All" || it.bloodGroup == group }
            .filter {
                query.isEmpty() ||
                    it.name.contains(query, ignoreCase = true) ||
                    it.bloodGroup.contains(query, ignoreCase = true) ||
                    it.city.contains(query, ignoreCase = true)
            }
            .sortedBy { it.distanceKm }
        adapter.submitList(result)
    }
}
