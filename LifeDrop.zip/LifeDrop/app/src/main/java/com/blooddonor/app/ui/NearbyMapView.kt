package com.blooddonor.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.blooddonor.app.data.Donor
import kotlin.math.hypot

/**
 * A lightweight, offline map drawn with Canvas (no Google Maps API key needed).
 * Shows the user's position in the centre and a pin for every donor. Tap a pin to select it.
 */
class NearbyMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var donors: List<Donor> = emptyList()
        set(value) { field = value; invalidate() }

    var selectedId: Int = -1
        set(value) { field = value; invalidate() }

    var onDonorSelected: ((Donor) -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val pinPath = Path()

    private fun pinX(d: Donor) = d.mapX * width
    private fun pinY(d: Donor) = d.mapY * (height - 120 * dp) + 40 * dp

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        canvas.drawColor(Color.parseColor("#E9EFE4"))

        // parks
        fill.color = Color.parseColor("#D6E7C8")
        canvas.drawRoundRect(0.05f * w, 0.08f * h, 0.30f * w, 0.22f * h, 12 * dp, 12 * dp, fill)
        canvas.drawRoundRect(0.62f * w, 0.60f * h, 0.95f * w, 0.78f * h, 12 * dp, 12 * dp, fill)

        // river
        stroke.color = Color.parseColor("#C3DCEF")
        stroke.strokeWidth = 18 * dp
        val river = Path().apply {
            moveTo(0f, 0.55f * h)
            quadTo(0.35f * w, 0.40f * h, 0.55f * w, 0.55f * h)
            quadTo(0.80f * w, 0.72f * h, w, 0.62f * h)
        }
        canvas.drawPath(river, stroke)

        // minor roads
        stroke.color = Color.WHITE
        stroke.strokeWidth = 5 * dp
        canvas.drawLine(0f, 0.25f * h, w, 0.40f * h, stroke)
        canvas.drawLine(0.25f * w, 0f, 0.40f * w, h, stroke)
        canvas.drawLine(0.75f * w, 0f, 0.62f * w, h, stroke)
        canvas.drawLine(0f, 0.85f * h, w, 0.78f * h, stroke)

        // main roads
        stroke.strokeWidth = 9 * dp
        canvas.drawLine(0f, 0.70f * h, w, 0.28f * h, stroke)
        stroke.color = Color.parseColor("#F6E9B9")
        stroke.strokeWidth = 7 * dp
        canvas.drawLine(0.05f * w, 0f, 0.95f * w, h, stroke)

        // user position (centre)
        val cx = w / 2f
        val cy = (h - 120 * dp) / 2f + 40 * dp
        fill.color = Color.argb(60, 47, 123, 245)
        canvas.drawCircle(cx, cy, 20 * dp, fill)
        fill.color = Color.WHITE
        canvas.drawCircle(cx, cy, 9 * dp, fill)
        fill.color = Color.parseColor("#2F7BF5")
        canvas.drawCircle(cx, cy, 6.5f * dp, fill)

        // donor pins, selected one drawn last
        donors.filter { it.id != selectedId }.forEach { drawPin(canvas, it, false) }
        donors.firstOrNull { it.id == selectedId }?.let { drawPin(canvas, it, true) }
    }

    private fun drawPin(canvas: Canvas, d: Donor, selected: Boolean) {
        val x = pinX(d)
        val y = pinY(d)
        val r = (if (selected) 13f else 10f) * dp
        val color = when {
            !d.available -> Color.parseColor("#9E9E9E")
            selected -> Color.parseColor("#B8121A")
            else -> Color.parseColor("#D71920")
        }
        // soft shadow
        fill.color = Color.argb(40, 0, 0, 0)
        canvas.drawOval(x - r * 0.6f, y - r * 0.2f, x + r * 0.6f, y + r * 0.2f, fill)
        // teardrop
        fill.color = color
        pinPath.reset()
        pinPath.moveTo(x, y)
        pinPath.lineTo(x - r * 0.85f, y - r * 1.45f)
        pinPath.lineTo(x + r * 0.85f, y - r * 1.45f)
        pinPath.close()
        canvas.drawPath(pinPath, fill)
        canvas.drawCircle(x, y - r * 2f, r, fill)
        fill.color = Color.WHITE
        canvas.drawCircle(x, y - r * 2f, r * 0.42f, fill)
        if (selected) {
            stroke.color = Color.WHITE
            stroke.strokeWidth = 2 * dp
            canvas.drawCircle(x, y - r * 2f, r, stroke)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val hit = donors
                    .map { it to hypot(event.x - pinX(it), event.y - (pinY(it) - 14 * dp)) }
                    .filter { it.second < 30 * dp }
                    .minByOrNull { it.second }
                if (hit != null) {
                    onDonorSelected?.invoke(hit.first)
                } else {
                    performClick()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
