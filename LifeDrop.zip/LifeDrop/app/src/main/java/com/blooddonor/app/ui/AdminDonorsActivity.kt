package com.blooddonor.app.ui

import android.os.Bundle
import android.util.Patterns
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.Donor
import com.blooddonor.app.databinding.ActivityAdminDonorsBinding
import com.blooddonor.app.databinding.DialogDonorBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.random.Random

class AdminDonorsActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminDonorsBinding
    private lateinit var adapter: AdminDonorAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAdminDonorsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.btnAdd.setOnClickListener { showDonorDialog(null) }
        // The Super Admin only views donors; each bank admin adds donors to their own bank.
        if (AppStore.isSuperAdmin()) b.btnAdd.visibility = View.GONE

        adapter = AdminDonorAdapter(
            onEdit = { showDonorDialog(it) },
            onDelete = { confirmDelete(it) }
        )
        b.rv.adapter = adapter
        load()
    }

    private fun load() {
        val list = if (AppStore.isSuperAdmin()) AppStore.allDonors() else AppStore.donorsOfBank(AppStore.myBankId())
        adapter.submitList(list)
        b.tvEmpty.text = "No donors yet. Tap + to add one."
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmDelete(donor: Donor) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete donor")
            .setMessage("Delete ${donor.name}?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                AppStore.deleteDonor(donor.id)
                toast("Donor deleted")
                load()
            }
            .show()
    }

    private fun showDonorDialog(existing: Donor?) {
        val d = DialogDonorBinding.inflate(layoutInflater)
        val groups = resources.getStringArray(R.array.blood_groups)
        val genders = resources.getStringArray(R.array.genders)

        if (existing != null) {
            d.etName.setText(existing.name)
            d.etAge.setText(existing.age.toString())
            d.etDistance.setText(existing.distanceKm.toString())
            d.etPhone.setText(existing.phone)
            d.etEmail.setText(existing.email)
            d.etCity.setText(existing.city)
            d.spBloodGroup.setSelection(groups.indexOf(existing.bloodGroup).coerceAtLeast(0))
            d.spGender.setSelection(genders.indexOf(existing.gender).coerceAtLeast(0))
            d.swAvailable.isChecked = existing.available
        } else {
            d.etCity.setText("Pune, Maharashtra")
            d.swAvailable.isChecked = true
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "Add Donor" else "Edit Donor")
            .setView(d.root)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            listOf(d.tilEtName, d.tilEtAge, d.tilEtDistance, d.tilEtPhone, d.tilEtEmail, d.tilEtCity)
                .forEach { it.error = null }

            val name = d.etName.text.toString().trim()
            val age = d.etAge.text.toString().trim().toIntOrNull()
            val distance = d.etDistance.text.toString().trim().toIntOrNull()
            val phone = d.etPhone.text.toString().trim()
            val email = d.etEmail.text.toString().trim()
            val city = d.etCity.text.toString().trim()

            var ok = true
            if (name.length < 2) { d.tilEtName.error = "Enter the donor's name"; ok = false }
            if (age == null || age !in 18..65) { d.tilEtAge.error = "Age must be between 18 and 65"; ok = false }
            if (distance == null || distance < 0) { d.tilEtDistance.error = "Enter the distance in km"; ok = false }
            if (phone.filter { it.isDigit() }.length < 10) { d.tilEtPhone.error = "Enter a valid phone number"; ok = false }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { d.tilEtEmail.error = "Enter a valid email"; ok = false }
            if (city.isEmpty()) { d.tilEtCity.error = "Enter the city"; ok = false }
            if (!ok || age == null || distance == null) return@setOnClickListener

            val donor = Donor(
                id = existing?.id ?: 0,
                name = name,
                bloodGroup = d.spBloodGroup.selectedItem.toString(),
                gender = d.spGender.selectedItem.toString(),
                age = age,
                distanceKm = distance,
                city = city,
                phone = phone,
                email = email,
                lastDonation = existing?.lastDonation ?: "Never",
                available = d.swAvailable.isChecked,
                mapX = existing?.mapX ?: (0.1f + Random.nextFloat() * 0.8f),
                mapY = existing?.mapY ?: (0.1f + Random.nextFloat() * 0.8f),
                bankId = existing?.bankId ?: AppStore.myBankId().toInt(),
                userId = existing?.userId ?: 0L
            )
            AppStore.saveDonor(donor)
            toast(if (existing == null) "Donor added" else "Donor updated")
            dialog.dismiss()
            load()
        }
    }
}
