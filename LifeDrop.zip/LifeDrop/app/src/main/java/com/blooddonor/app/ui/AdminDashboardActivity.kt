package com.blooddonor.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.BankStore
import com.blooddonor.app.databinding.ActivityAdminDashboardBinding

class AdminDashboardActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!AppStore.isAdmin()) {
            // Only the administrator may see this screen.
            openHomeFresh()
            finish()
            return
        }
        b = ActivityAdminDashboardBinding.inflate(layoutInflater)
        setContentView(b.root)

        val superAdmin = AppStore.isSuperAdmin()
        b.tvTitle.text = if (superAdmin) "Super Admin Dashboard"
        else BankStore.bankName(AppStore.myBankId()).ifEmpty { "Blood Bank Dashboard" }

        b.btnLogout.setOnClickListener { confirmLogout() }
        b.rowDonors.setOnClickListener { openScreen<AdminDonorsActivity>() }
        b.rowUsers.setOnClickListener { openScreen<AdminUsersActivity>() }
        b.rowRequests.setOnClickListener { openScreen<AdminRequestsActivity>() }
        b.rowBanks.setOnClickListener { openList(ListScreenActivity.MODE_BANKS) }
        b.rowBankAdmins.setOnClickListener { openList(ListScreenActivity.MODE_BANK_ADMINS) }
        b.rowStock.setOnClickListener { openList(ListScreenActivity.MODE_STOCK) }
        b.rowDonationRequests.setOnClickListener { openList(ListScreenActivity.MODE_DONATION_REQUESTS) }
        b.rowStats.setOnClickListener { openList(ListScreenActivity.MODE_STATS) }
        // Every admin is also a normal user, so can open the donor view.
        b.rowDonorView.setOnClickListener {
            AppStore.adminMode = false
            openHomeFresh()
        }

        // Super Admin: all banks, admins, users. Bank Admin: own stock and donation requests.
        val vis = { show: Boolean -> if (show) View.VISIBLE else View.GONE }
        b.rowUsers.visibility = vis(superAdmin)
        b.rowBanks.visibility = vis(superAdmin)
        b.rowBankAdmins.visibility = vis(superAdmin)
        b.rowStock.visibility = vis(!superAdmin)
        b.rowDonationRequests.visibility = vis(true)
    }

    private fun openList(mode: String) =
        openScreen<ListScreenActivity> { putExtra(ListScreenActivity.EXTRA_MODE, mode) }

    override fun onResume() {
        super.onResume()
        if (!::b.isInitialized) return
        if (AppStore.isSuperAdmin()) {
            val stats = AppStore.getStats()
            b.tvLbl1.text = "Users"; b.tvLbl2.text = "Donors"; b.tvLbl3.text = "Requests"; b.tvLbl4.text = "Pending"
            b.tvUsers.text = stats.users.toString()
            b.tvDonors.text = stats.donors.toString()
            b.tvRequests.text = stats.requests.toString()
            b.tvPending.text = stats.pending.toString()
        } else {
            val bankId = AppStore.myBankId()
            b.tvLbl1.text = "Bank donors"; b.tvLbl2.text = "Units in stock"
            b.tvLbl3.text = "Open requests"; b.tvLbl4.text = "Donation requests"
            b.tvUsers.text = AppStore.donorsOfBank(bankId).size.toString()
            b.tvDonors.text = BankStore.stockOf(bankId).sumOf { it.units }.toString()
            b.tvRequests.text = AppStore.getStats().pending.toString()
            b.tvPending.text = BankStore.donationRequestsOfBank(bankId).count { it.status == BankStore.DR_PENDING }.toString()
        }
    }
}
