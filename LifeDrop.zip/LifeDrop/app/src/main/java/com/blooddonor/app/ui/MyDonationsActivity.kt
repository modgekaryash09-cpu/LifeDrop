package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityMyDonationsBinding

class MyDonationsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityMyDonationsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.rvDonations.adapter = DonationAdapter(AppStore.donations) { d ->
            toast("Certificate for ${d.date} will be available soon")
        }
    }
}
