package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.R
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityRequestBloodBinding

class RequestBloodActivity : AppCompatActivity() {
    private lateinit var b: ActivityRequestBloodBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRequestBloodBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        val groups = resources.getStringArray(R.array.blood_groups)
        val preset = intent.getStringExtra(EXTRA_BLOOD_GROUP) ?: AppStore.getUser().bloodGroup
        val index = groups.indexOf(preset)
        if (index >= 0) b.spBloodGroup.setSelection(index)

        b.btnSubmitRequest.setOnClickListener { submit() }
    }

    private fun submit() {
        b.tilEtHospital.error = null
        val hospital = b.etHospital.text.toString().trim()
        if (hospital.isEmpty()) {
            b.tilEtHospital.error = "Enter the hospital name"
            return
        }
        val request = AppStore.createRequest(
            bloodGroup = b.spBloodGroup.selectedItem.toString(),
            units = b.spUnits.selectedItem.toString(),
            hospital = hospital,
            reason = b.etReason.text.toString().trim()
        )
        openScreen<RequestStatusActivity> { putExtra(RequestStatusActivity.EXTRA_REQUEST_ID, request.id) }
        finish()
    }

    companion object {
        const val EXTRA_BLOOD_GROUP = "blood_group"
    }
}
