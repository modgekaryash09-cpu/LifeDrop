package com.blooddonor.app.ui

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.DialogChangePasswordBinding
import com.blooddonor.app.databinding.DialogForgotPasswordBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

fun Activity.confirmLogout() {
    MaterialAlertDialogBuilder(this)
        .setTitle("Logout")
        .setMessage("Are you sure you want to logout?")
        .setNegativeButton("Cancel", null)
        .setPositiveButton("Logout") { _, _ ->
            AppStore.logout()
            restartAtLogin()
        }
        .show()
}

fun Activity.showChangePasswordDialog() {
    val d = DialogChangePasswordBinding.inflate(layoutInflater)
    val dialog = MaterialAlertDialogBuilder(this)
        .setTitle("Change Password")
        .setView(d.root)
        .setPositiveButton("Update", null)
        .setNegativeButton("Cancel", null)
        .create()
    dialog.show()
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
        d.tilEtCurrent.error = null
        d.tilEtNew.error = null
        d.tilEtConfirm.error = null
        val current = d.etCurrent.text.toString()
        val new = d.etNew.text.toString()
        val confirm = d.etConfirm.text.toString()
        when {
            !AppStore.checkPassword(current) -> d.tilEtCurrent.error = "Current password is incorrect"
            new.length < 6 -> d.tilEtNew.error = "Use at least 6 characters"
            new != confirm -> d.tilEtConfirm.error = "Passwords do not match"
            else -> {
                AppStore.setPassword(new)
                toast("Password updated")
                dialog.dismiss()
            }
        }
    }
}

fun Activity.showForgotPasswordDialog() {
    val d = DialogForgotPasswordBinding.inflate(layoutInflater)
    val dialog = MaterialAlertDialogBuilder(this)
        .setTitle("Reset Password")
        .setView(d.root)
        .setPositiveButton("Reset", null)
        .setNegativeButton("Cancel", null)
        .create()
    dialog.show()
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
        d.tilEtEmail.error = null
        d.tilEtNew.error = null
        val id = d.etEmail.text.toString()
        val new = d.etNew.text.toString()
        when {
            new.length < 6 -> d.tilEtNew.error = "Use at least 6 characters"
            !AppStore.resetPassword(id, new) -> d.tilEtEmail.error = "No account found with this email/phone"
            else -> {
                toast("Password reset. Please login.")
                dialog.dismiss()
            }
        }
    }
}
