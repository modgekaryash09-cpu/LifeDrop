package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivityDonorProfileBinding

class DonorProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityDonorProfileBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        val donor = AppStore.donorById(intent.getIntExtra(EXTRA_DONOR_ID, -1))
        if (donor == null) {
            toast("Donor not found")
            finish()
            return
        }
        b.tvName.text = donor.name
        b.tvInfo.text = "${donor.bloodGroup}  |  ${donor.gender}  |  ${donor.age} years"
        b.tvLocation.text = donor.city
        b.tvPhone.text = donor.phone
        b.tvEmail.text = donor.email
        b.tvLastDonation.text = donor.lastDonation

        b.tvPhone.setOnClickListener { dial(donor.phone) }
        b.btnRequestBlood.setOnClickListener {
            openScreen<RequestBloodActivity> { putExtra(RequestBloodActivity.EXTRA_BLOOD_GROUP, donor.bloodGroup) }
        }
    }

    companion object {
        const val EXTRA_DONOR_ID = "donor_id"
    }
}
