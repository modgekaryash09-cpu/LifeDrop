package com.blooddonor.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.databinding.ActivityWelcomeBinding

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnGetStarted.setOnClickListener {
            openScreen<LoginActivity>()
            finish()
        }
    }
}
