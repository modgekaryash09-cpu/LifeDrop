package com.blooddonor.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.BankStore
import com.blooddonor.app.data.BloodBank
import com.blooddonor.app.databinding.ActivityListBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * One list screen used for every new role screen. EXTRA_MODE picks what it shows:
 * banks / bank admins (Super Admin), stock / donation requests / statistics (admins),
 * nearby banks / my requests (donors).
 */
class ListScreenActivity : AppCompatActivity() {
    private lateinit var b: ActivityListBinding
    private lateinit var adapter: RowAdapter
    private var mode = MODE_STATS

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_STATS
        val adminOnly = mode in listOf(MODE_BANKS, MODE_BANK_ADMINS, MODE_STOCK, MODE_DONATION_REQUESTS, MODE_STATS)
        if (adminOnly && !AppStore.isAdmin()) { finish(); return }
        if ((mode == MODE_BANKS || mode == MODE_BANK_ADMINS) && !AppStore.isSuperAdmin()) { finish(); return }

        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.tvTitle.text = when (mode) {
            MODE_BANKS -> "Blood Banks"
            MODE_BANK_ADMINS -> "Bank Administrators"
            MODE_STOCK -> "Blood Stock"
            MODE_DONATION_REQUESTS -> "Donation Requests"
            MODE_NEARBY_BANKS -> "Nearby Blood Banks"
            MODE_MY_REQUESTS -> "My Requests"
            else -> "Statistics"
        }
        b.btnBack.setOnClickListener { finish() }
        if (mode == MODE_BANKS || mode == MODE_BANK_ADMINS) {
            b.btnAdd.visibility = View.VISIBLE
            b.btnAdd.setOnClickListener { if (mode == MODE_BANKS) addBankDialog() else addAdminDialog() }
        }
        adapter = RowAdapter(::onPrimary, ::onSecondary, ::onRowClick)
        b.rv.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        if (::b.isInitialized) load()
    }

    private fun load() {
        val rows = when (mode) {
            MODE_BANKS -> bankRows()
            MODE_BANK_ADMINS -> adminRows()
            MODE_STOCK -> stockRows()
            MODE_DONATION_REQUESTS -> donationRows()
            MODE_NEARBY_BANKS -> nearbyRows()
            MODE_MY_REQUESTS -> myRequestRows()
            else -> statRows()
        }
        adapter.submitList(rows)
        b.tvEmpty.text = "Nothing here yet"
        b.tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------- rows
    private fun bankRows() = BankStore.allBanks().map { bk ->
        val pending = bk.status == BankStore.PENDING
        val approved = bk.status == BankStore.APPROVED
        RowItem(
            key = bk.id.toString(), title = bk.name,
            status = bk.status.lowercase().replaceFirstChar { it.uppercase() },
            tone = if (approved) TONE_GOOD else if (pending) TONE_WARN else TONE_NEUTRAL,
            line1 = "${bk.address}  |  ${bk.distanceKm} km",
            line2 = "${bk.phone}  |  ${bk.email}",
            line3 = "Admin: ${bk.adminNames.ifEmpty { "not assigned" }}  |  Stock: ${bk.totalUnits} units",
            primary = if (approved) null else "Approve",
            secondary = if (pending) "Reject" else "Delete"
        )
    }

    private fun adminRows() = BankStore.bankAdmins().map { u ->
        RowItem(u.id.toString(), u.fullName, "Bank Admin", TONE_GOOD, u.email, u.phone,
            "Bank: ${u.bankName.ifEmpty { "none" }}", "Reset password", "Remove")
    }

    private fun stockRows(): List<RowItem> {
        val bankId = AppStore.myBankId()
        return BankStore.stockOf(bankId).map { s ->
            RowItem(s.bloodGroup, "Blood group ${s.bloodGroup}", "${s.units} units",
                if (s.units < BankStore.LOW_STOCK) TONE_WARN else TONE_GOOD,
                if (s.units < BankStore.LOW_STOCK) "Low stock" else "", "", "Tap a card to set the exact number",
                "+1", "-1")
        }
    }

    private fun donationRows(): List<RowItem> {
        val list = if (AppStore.isSuperAdmin()) BankStore.allDonationRequests()
        else BankStore.donationRequestsOfBank(AppStore.myBankId())
        return list.map { r ->
            val pending = r.status == BankStore.DR_PENDING
            RowItem("dr${r.id}", "${r.userName} - ${r.units} unit(s) ${r.bloodGroup}", r.status,
                when (r.status) { BankStore.DR_APPROVED -> TONE_GOOD; BankStore.DR_PENDING -> TONE_WARN; else -> TONE_NEUTRAL },
                "Bank: ${r.bankName}", "Preferred date: ${r.preferredDate}", "",
                if (pending) "Approve" else null, if (pending) "Reject" else null)
        }
    }

    private fun nearbyRows() = BankStore.approvedBanks().map { bk ->
        RowItem(bk.id.toString(), bk.name, "${bk.distanceKm} km", TONE_GOOD, bk.address, bk.phone,
            "Stock: ${bk.totalUnits} units  (tap for details)", "Donate here", "Call")
    }

    private fun myRequestRows(): List<RowItem> {
        val rows = ArrayList<RowItem>()
        BankStore.myBloodRequests().forEach { r ->
            val open = r.status == AppStore.STATUS_PENDING
            rows += RowItem("br${r.id}", "${r.id}  |  ${r.bloodGroup}  |  ${r.units}", r.status,
                if (r.status.startsWith("Fulfilled")) TONE_GOOD else if (open) TONE_WARN else TONE_NEUTRAL,
                r.hospital, r.date, "", null, if (open) "Cancel request" else null)
        }
        BankStore.myDonationRequests().forEach { r ->
            rows += RowItem("dr${r.id}", "Donation at ${r.bankName}", r.status,
                when (r.status) { BankStore.DR_APPROVED -> TONE_GOOD; BankStore.DR_PENDING -> TONE_WARN; else -> TONE_NEUTRAL },
                "${r.units} unit(s) ${r.bloodGroup}", r.preferredDate)
        }
        return rows
    }

    private fun statRows(): List<RowItem> {
        val stats = if (AppStore.isSuperAdmin()) BankStore.cityStats() else BankStore.bankStats(AppStore.myBankId())
        return stats.mapIndexed { i, s -> RowItem("s$i", s.label, s.value, TONE_NEUTRAL) }
    }

    // ---------------------------------------------------------------- actions
    private fun onPrimary(r: RowItem) {
        when (mode) {
            MODE_BANKS -> { BankStore.setBankStatus(r.key.toLong(), BankStore.APPROVED); toast("${r.title} approved") }
            MODE_BANK_ADMINS -> { resetPasswordDialog(r); return }
            MODE_STOCK -> changeStock(r.key, +1)
            MODE_DONATION_REQUESTS -> { BankStore.decideDonationRequest(r.key.removePrefix("dr").toLong(), true); toast("Donation approved, stock updated") }
            MODE_NEARBY_BANKS -> BankStore.getBank(r.key.toLong())?.let { showDonateDialog(it) }
        }
        load()
    }

    private fun onSecondary(r: RowItem) {
        when (mode) {
            MODE_BANKS ->
                if (r.secondary == "Reject") { BankStore.setBankStatus(r.key.toLong(), BankStore.REJECTED); toast("${r.title} rejected") }
                else { confirm("Delete ${r.title}? Its stock and donation requests are deleted too.") { BankStore.deleteBank(r.key.toLong()); load() }; return }
            MODE_BANK_ADMINS -> { confirm("Remove ${r.title} as bank administrator?") { BankStore.removeBankAdmin(r.key.toLong()); load() }; return }
            MODE_STOCK -> changeStock(r.key, -1)
            MODE_DONATION_REQUESTS -> { BankStore.decideDonationRequest(r.key.removePrefix("dr").toLong(), false); toast("Donation rejected") }
            MODE_NEARBY_BANKS -> BankStore.getBank(r.key.toLong())?.let { dial(it.phone) }
            MODE_MY_REQUESTS -> { AppStore.updateRequestStatus(r.key.removePrefix("br"), AppStore.STATUS_CANCELLED); toast("Request cancelled") }
        }
        load()
    }

    private fun onRowClick(r: RowItem) {
        when (mode) {
            MODE_STOCK -> showForm("Blood group ${r.key}", listOf(Field("units", "Units in stock", FieldType.NUMBER, initial = r.status.substringBefore(" "))), "Update") { v ->
                BankStore.setStock(AppStore.myBankId(), r.key, v.getValue("units").toInt())
                load(); null
            }
            MODE_NEARBY_BANKS -> {
                val stock = BankStore.stockOf(r.key.toLong()).joinToString("\n") { "${it.bloodGroup}:  ${it.units} units" }
                MaterialAlertDialogBuilder(this).setTitle("${r.title} - blood stock").setMessage(stock)
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun changeStock(group: String, delta: Int) {
        val bankId = AppStore.myBankId()
        val now = BankStore.stockOf(bankId).first { it.bloodGroup == group }.units
        BankStore.setStock(bankId, group, now + delta)
    }

    private fun confirm(message: String, action: () -> Unit) {
        MaterialAlertDialogBuilder(this).setMessage(message)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Yes") { _, _ -> action() }.show()
    }

    private fun resetPasswordDialog(r: RowItem) {
        showForm("Reset password for ${r.title}", listOf(Field("pw", "New password", FieldType.PASSWORD)), "Reset") { v ->
            BankStore.resetUserPassword(r.key.toLong(), v.getValue("pw"))
            toast("Password changed"); null
        }
    }

    private fun addBankDialog() {
        showForm("Add Blood Bank", listOf(
            Field("name", "Blood bank name"), Field("address", "Address"),
            Field("phone", "Bank phone", FieldType.PHONE), Field("email", "Bank email", FieldType.EMAIL),
            Field("km", "Distance from city centre (km)", FieldType.NUMBER),
            Field("an", "Administrator name"), Field("ae", "Administrator email", FieldType.EMAIL),
            Field("ap", "Administrator phone", FieldType.PHONE), Field("apw", "Administrator password", FieldType.PASSWORD)
        ), "Add") { v ->
            val err = BankStore.createBankByAdmin(v.getValue("name"), v.getValue("address"), v.getValue("phone"),
                v.getValue("email"), v.getValue("km").toInt(), v.getValue("an"), v.getValue("ae"),
                v.getValue("ap"), v.getValue("apw"))
            if (err == null) { toast("Blood bank added"); load() }
            err
        }
    }

    private fun addAdminDialog() {
        val banks: List<BloodBank> = BankStore.approvedBanks()
        if (banks.isEmpty()) { toast("Add or approve a blood bank first"); return }
        val names = banks.map { it.name }
        showForm("Add Bank Administrator", listOf(
            Field("bank", "Blood bank", FieldType.CHOICE, names, names.first()),
            Field("n", "Name"), Field("e", "Email", FieldType.EMAIL),
            Field("p", "Phone", FieldType.PHONE), Field("pw", "Password", FieldType.PASSWORD)
        ), "Add") { v ->
            val bank = banks[names.indexOf(v.getValue("bank")).coerceAtLeast(0)]
            val err = BankStore.addBankAdmin(v.getValue("n"), v.getValue("e"), v.getValue("p"), v.getValue("pw"), bank.id)
            if (err == null) { toast("Administrator added"); load() }
            err
        }
    }

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_BANKS = "banks"
        const val MODE_BANK_ADMINS = "bank_admins"
        const val MODE_STOCK = "stock"
        const val MODE_DONATION_REQUESTS = "donation_requests"
        const val MODE_NEARBY_BANKS = "nearby_banks"
        const val MODE_MY_REQUESTS = "my_requests"
        const val MODE_STATS = "stats"
    }
}
