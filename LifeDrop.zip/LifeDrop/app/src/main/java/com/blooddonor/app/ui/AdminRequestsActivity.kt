package com.blooddonor.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.data.BankStore
import com.blooddonor.app.databinding.ActivityAdminRequestsBinding

class AdminRequestsActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminRequestsBinding
    private lateinit var adapter: AdminRequestAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAdminRequestsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        adapter = AdminRequestAdapter { item, status ->
            if (status == AppStore.STATUS_FULFILLED && AppStore.isBankAdmin()) {
                // A bank admin fulfils the request from this bank's blood stock.
                val error = BankStore.fulfillRequest(item.request.id, AppStore.myBankId())
                toast(error ?: "${item.request.id} fulfilled from stock")
            } else {
                AppStore.updateRequestStatus(item.request.id, status)
                toast("${item.request.id} marked $status")
            }
            load()
        }
        b.rv.adapter = adapter
        load()
    }

    private fun load() {
        val list = AppStore.allRequests()
        adapter.submitList(list)
        b.tvEmpty.text = "No blood requests yet"
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }
}
