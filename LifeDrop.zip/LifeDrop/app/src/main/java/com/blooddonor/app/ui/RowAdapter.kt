package com.blooddonor.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.blooddonor.app.R
import com.blooddonor.app.databinding.ItemAdminRequestBinding

const val TONE_GOOD = 0
const val TONE_NEUTRAL = 1
const val TONE_WARN = 2

/** One generic card row (title, status badge, three text lines, up to two buttons). */
data class RowItem(
    val key: String,
    val title: String,
    val status: String = "",
    val tone: Int = TONE_NEUTRAL,
    val line1: String = "",
    val line2: String = "",
    val line3: String = "",
    val primary: String? = null,
    val secondary: String? = null
)

class RowAdapter(
    private val onPrimary: (RowItem) -> Unit,
    private val onSecondary: (RowItem) -> Unit,
    private val onClick: (RowItem) -> Unit
) : ListAdapter<RowItem, RowAdapter.VH>(Diff) {

    class VH(val b: ItemAdminRequestBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAdminRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = getItem(position)
        val ctx = holder.b.root.context
        holder.b.tvRequestId.text = r.title
        setLine(holder.b.tvRequester, r.line1)
        setLine(holder.b.tvDetails, r.line2)
        setLine(holder.b.tvDate, r.line3)

        val badge = holder.b.tvStatus
        badge.visibility = if (r.status.isEmpty()) View.GONE else View.VISIBLE
        badge.text = r.status
        when (r.tone) {
            TONE_GOOD -> { badge.setTextColor(ctx.getColor(R.color.green)); badge.setBackgroundResource(R.drawable.bg_badge) }
            TONE_WARN -> { badge.setTextColor(ctx.getColor(R.color.orange)); badge.setBackgroundResource(R.drawable.bg_pinkbox) }
            else -> { badge.setTextColor(ctx.getColor(R.color.muted)); badge.setBackgroundResource(R.drawable.bg_badge_off) }
        }

        holder.b.rowButtons.visibility = if (r.primary == null && r.secondary == null) View.GONE else View.VISIBLE
        holder.b.btnFulfilled.visibility = if (r.primary == null) View.GONE else View.VISIBLE
        holder.b.btnCancel.visibility = if (r.secondary == null) View.GONE else View.VISIBLE
        holder.b.btnFulfilled.text = r.primary ?: ""
        holder.b.btnCancel.text = r.secondary ?: ""
        holder.b.btnFulfilled.setOnClickListener { onPrimary(r) }
        holder.b.btnCancel.setOnClickListener { onSecondary(r) }
        holder.b.root.setOnClickListener { onClick(r) }
    }

    private fun setLine(view: TextView, text: String) {
        view.text = text
        view.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    object Diff : DiffUtil.ItemCallback<RowItem>() {
        override fun areItemsTheSame(a: RowItem, b: RowItem) = a.key == b.key
        override fun areContentsTheSame(a: RowItem, b: RowItem) = a == b
    }
}
