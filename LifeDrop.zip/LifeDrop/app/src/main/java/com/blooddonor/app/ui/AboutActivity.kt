package com.blooddonor.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "1.0.0"
        }
        b.tvVersion.text = "Version $version"

        b.btnContactUs.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:support@lifedrop.app")
                putExtra(Intent.EXTRA_SUBJECT, "LifeDrop App support")
            }
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                toast("No email app found. Write to support@lifedrop.app")
            }
        }
    }
}
