package com.blooddonor.app.data

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Blood banks, blood stock, bank administrators and donation requests.
 * Works on the same SQLite database as [AppStore].
 */
object BankStore {
    const val APPROVED = "APPROVED"
    const val PENDING = "PENDING"
    const val REJECTED = "REJECTED"

    const val DR_PENDING = "Pending"
    const val DR_APPROVED = "Approved"
    const val DR_REJECTED = "Rejected"

    private val rdb: SQLiteDatabase get() = AppStore.rdb
    private val wdb: SQLiteDatabase get() = AppStore.wdb

    private val groups: List<String> get() = BloodDonorDb.BLOOD_GROUPS

    private fun scalar(sql: String, vararg args: String): Long =
        rdb.rawQuery(sql, args).use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L }

    fun today(): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

    // -------------------------------------------------------------------- banks
    private const val BANK_SELECT =
        "SELECT b.*, " +
            "IFNULL((SELECT SUM(s.units) FROM blood_stock s WHERE s.bank_id = b.id), 0) AS total_units, " +
            "IFNULL((SELECT GROUP_CONCAT(u.full_name, ', ') FROM users u WHERE u.bank_id = b.id AND u.role = 1), '') AS admin_names " +
            "FROM blood_banks b "

    private fun Cursor.toBank() = BloodBank(
        id = getLong(getColumnIndexOrThrow("id")),
        name = getString(getColumnIndexOrThrow("name")),
        city = getString(getColumnIndexOrThrow("city")),
        address = getString(getColumnIndexOrThrow("address")),
        phone = getString(getColumnIndexOrThrow("phone")),
        email = getString(getColumnIndexOrThrow("email")),
        status = getString(getColumnIndexOrThrow("status")),
        distanceKm = getInt(getColumnIndexOrThrow("distance_km")),
        totalUnits = getInt(getColumnIndexOrThrow("total_units")),
        adminNames = getString(getColumnIndexOrThrow("admin_names"))
    )

    private fun queryBanks(where: String, order: String, vararg args: String): List<BloodBank> =
        rdb.rawQuery(BANK_SELECT + where + " ORDER BY " + order, args).use { c ->
            val list = ArrayList<BloodBank>()
            while (c.moveToNext()) list.add(c.toBank())
            list
        }

    /** All banks, registrations waiting for approval first (Super Admin). */
    fun allBanks(): List<BloodBank> =
        queryBanks("", "CASE b.status WHEN 'PENDING' THEN 0 WHEN 'APPROVED' THEN 1 ELSE 2 END, b.distance_km")

    /** Approved banks, nearest first (donors). */
    fun approvedBanks(): List<BloodBank> = queryBanks("WHERE b.status = 'APPROVED'", "b.distance_km")

    fun getBank(id: Long): BloodBank? = queryBanks("WHERE b.id = ?", "b.id", id.toString()).firstOrNull()

    fun bankName(id: Long): String = getBank(id)?.name ?: ""

    private fun ensureStock(db: SQLiteDatabase, bankId: Long) {
        groups.forEach { g ->
            db.insertWithOnConflict("blood_stock", null, ContentValues().apply {
                put("bank_id", bankId)
                put("blood_group", g)
                put("units", 0)
            }, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    /** Super Admin adds a bank together with its administrator account. Returns an error message or null. */
    fun createBankByAdmin(
        name: String, address: String, phone: String, email: String, distanceKm: Int,
        adminName: String, adminEmail: String, adminPhone: String, adminPassword: String
    ): String? {
        val db = wdb
        db.beginTransaction()
        try {
            val bankId = db.insert("blood_banks", null, ContentValues().apply {
                put("name", name)
                put("city", "Pune")
                put("address", address)
                put("phone", phone)
                put("email", email)
                put("status", APPROVED)
                put("distance_km", distanceKm)
                put("created_at", System.currentTimeMillis())
            })
            ensureStock(db, bankId)
            db.insertOrThrow("users", null, staffValues(adminName, adminPhone, adminEmail, adminPassword, bankId))
            db.setTransactionSuccessful()
            return null
        } catch (e: SQLiteConstraintException) {
            return "That admin email or phone number is already used by another account"
        } finally {
            db.endTransaction()
        }
    }

    /** A signed-in user applies to register a new blood bank; a Super Admin must approve it. */
    fun registerBankByUser(name: String, address: String, phone: String, email: String): Boolean {
        if (scalar("SELECT COUNT(*) FROM blood_banks WHERE applicant_user_id = ? AND status = 'PENDING'",
                AppStore.currentUserId.toString()) > 0) return false
        wdb.insert("blood_banks", null, ContentValues().apply {
            put("name", name)
            put("city", "Pune")
            put("address", address)
            put("phone", phone)
            put("email", email)
            put("status", PENDING)
            put("applicant_user_id", AppStore.currentUserId)
            put("distance_km", 10)
            put("created_at", System.currentTimeMillis())
        })
        return true
    }

    /** Approve or reject a registration. Approving makes the applicant the bank's admin. */
    fun setBankStatus(id: Long, status: String) {
        val db = wdb
        db.beginTransaction()
        try {
            db.update("blood_banks", ContentValues().apply { put("status", status) }, "id = ?", arrayOf(id.toString()))
            if (status == APPROVED) {
                ensureStock(db, id)
                db.execSQL(
                    "UPDATE users SET role = 1, bank_id = ? WHERE role = 0 AND id = " +
                        "(SELECT applicant_user_id FROM blood_banks WHERE id = ?)",
                    arrayOf<Any>(id, id)
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Deletes a bank; its stock and donation requests go with it, its admins become normal users. */
    fun deleteBank(id: Long) {
        val db = wdb
        db.beginTransaction()
        try {
            db.execSQL("UPDATE users SET role = 0, bank_id = NULL WHERE role = 1 AND bank_id = ?", arrayOf<Any>(id))
            db.execSQL("UPDATE donors SET bank_id = NULL WHERE bank_id = ?", arrayOf<Any>(id))
            db.delete("blood_banks", "id = ?", arrayOf(id.toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // -------------------------------------------------------------------- stock
    fun stockOf(bankId: Long): List<StockRow> {
        val map = HashMap<String, Int>()
        rdb.rawQuery("SELECT blood_group, units FROM blood_stock WHERE bank_id = ?", arrayOf(bankId.toString())).use { c ->
            while (c.moveToNext()) map[c.getString(0)] = c.getInt(1)
        }
        return groups.map { StockRow(it, map[it] ?: 0) }
    }

    fun setStock(bankId: Long, group: String, units: Int) {
        wdb.insertWithOnConflict("blood_stock", null, ContentValues().apply {
            put("bank_id", bankId)
            put("blood_group", group)
            put("units", units.coerceAtLeast(0))
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ----------------------------------------------------------- bank admins
    private fun staffValues(name: String, phone: String, email: String, password: String, bankId: Long) =
        ContentValues().apply {
            put("full_name", name)
            put("phone", phone)
            put("phone_digits", phoneDigits(phone))
            put("email", email)
            put("blood_group", "O+")
            put("location", "Pune, Maharashtra")
            put("password_hash", sha256(password))
            put("role", AppStore.ROLE_BANK_ADMIN)
            put("bank_id", bankId)
        }

    fun bankAdmins(): List<UserRow> = AppStore.allUsers().filter { it.role == AppStore.ROLE_BANK_ADMIN }

    fun addBankAdmin(name: String, email: String, phone: String, password: String, bankId: Long): String? =
        try {
            wdb.insertOrThrow("users", null, staffValues(name, phone, email, password, bankId))
            null
        } catch (e: SQLiteConstraintException) {
            "That email or phone number is already used by another account"
        }

    fun removeBankAdmin(userId: Long) {
        wdb.execSQL("UPDATE users SET role = 0, bank_id = NULL WHERE role = 1 AND id = ?", arrayOf<Any>(userId))
    }

    fun resetUserPassword(userId: Long, password: String) {
        wdb.update("users", ContentValues().apply { put("password_hash", sha256(password)) },
            "id = ?", arrayOf(userId.toString()))
    }

    // ------------------------------------------------------------ donor profile
    /** Registers (or updates) the logged-in user as a donor of the chosen bank. */
    fun registerAsDonor(bankId: Long, bloodGroup: String, gender: String, age: Int): Boolean {
        val user = AppStore.getUser()
        val bank = getBank(bankId)
        val existing = AppStore.myDonor()
        val donor = Donor(
            id = existing?.id ?: 0,
            name = user.fullName,
            bloodGroup = bloodGroup,
            gender = gender,
            age = age,
            distanceKm = bank?.distanceKm ?: 5,
            city = user.location.ifEmpty { "Pune, Maharashtra" },
            phone = user.phone,
            email = user.email,
            lastDonation = existing?.lastDonation ?: "Never",
            available = existing?.available ?: true,
            mapX = existing?.mapX ?: (0.1f + kotlin.random.Random.nextFloat() * 0.8f),
            mapY = existing?.mapY ?: (0.1f + kotlin.random.Random.nextFloat() * 0.8f),
            bankId = bankId.toInt(),
            userId = AppStore.currentUserId
        )
        return AppStore.saveDonor(donor)
    }

    // ------------------------------------------------------ donation requests
    private const val DR_SELECT =
        "SELECT r.id, u.full_name, r.bank_id, b.name, r.blood_group, r.units, r.preferred_date, r.status " +
            "FROM donation_requests r JOIN users u ON u.id = r.user_id JOIN blood_banks b ON b.id = r.bank_id "

    private fun queryDr(where: String, vararg args: String): List<DonationRequest> =
        rdb.rawQuery(DR_SELECT + where + " ORDER BY r.created_at DESC", args).use { c ->
            val list = ArrayList<DonationRequest>()
            while (c.moveToNext()) {
                list.add(DonationRequest(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3),
                    c.getString(4), c.getInt(5), c.getString(6), c.getString(7)))
            }
            list
        }

    fun createDonationRequest(bankId: Long, bloodGroup: String, units: Int, date: String) {
        wdb.insert("donation_requests", null, ContentValues().apply {
            put("user_id", AppStore.currentUserId)
            put("bank_id", bankId)
            put("blood_group", bloodGroup)
            put("units", units)
            put("preferred_date", date)
            put("status", DR_PENDING)
            put("created_at", System.currentTimeMillis())
        })
    }

    fun donationRequestsOfBank(bankId: Long) = queryDr("WHERE r.bank_id = ?", bankId.toString())
    fun allDonationRequests() = queryDr("")
    fun myDonationRequests() = queryDr("WHERE r.user_id = ?", AppStore.currentUserId.toString())

    /** Approve (adds stock + donor history) or reject a donation request. */
    fun decideDonationRequest(id: Long, approve: Boolean) {
        val db = wdb
        db.beginTransaction()
        try {
            val row = db.rawQuery(
                "SELECT user_id, bank_id, blood_group, units, preferred_date, status FROM donation_requests WHERE id = ?",
                arrayOf(id.toString())
            ).use { c ->
                if (c.moveToFirst()) arrayOf(c.getLong(0), c.getLong(1), c.getString(2), c.getInt(3), c.getString(4), c.getString(5)) else null
            } ?: return
            if (row[5] != DR_PENDING) return
            val userId = row[0] as Long
            val bankId = row[1] as Long
            val group = row[2] as String
            val units = row[3] as Int
            val date = row[4] as String

            db.update("donation_requests", ContentValues().apply {
                put("status", if (approve) DR_APPROVED else DR_REJECTED)
            }, "id = ?", arrayOf(id.toString()))

            if (approve) {
                db.insertWithOnConflict("blood_stock", null, ContentValues().apply {
                    put("bank_id", bankId); put("blood_group", group); put("units", 0)
                }, SQLiteDatabase.CONFLICT_IGNORE)
                db.execSQL("UPDATE blood_stock SET units = units + ? WHERE bank_id = ? AND blood_group = ?",
                    arrayOf<Any>(units, bankId, group))
                db.insert("donations", null, ContentValues().apply {
                    put("user_id", userId)
                    put("donated_on", date)
                    put("blood_group", group)
                    put("units", units)
                })
                db.execSQL("UPDATE donors SET last_donation = ? WHERE user_id = ?", arrayOf<Any>(date, userId))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // --------------------------------------------------------- blood requests
    /** Blood requests made by the logged-in user, newest first. */
    fun myBloodRequests(): List<BloodRequest> =
        rdb.rawQuery(
            "SELECT id, request_date, blood_group, units, hospital, reason, status FROM requests " +
                "WHERE user_id = ? ORDER BY created_at DESC",
            arrayOf(AppStore.currentUserId.toString())
        ).use { c ->
            val list = ArrayList<BloodRequest>()
            while (c.moveToNext()) {
                list.add(BloodRequest(c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                    c.getString(4), c.getString(5), c.getString(6)))
            }
            list
        }

    /** A bank admin fulfils a city blood request from this bank's stock. Returns an error message or null. */
    fun fulfillRequest(requestId: String, bankId: Long): String? {
        val db = wdb
        db.beginTransaction()
        try {
            val req = db.rawQuery("SELECT blood_group, units, status FROM requests WHERE id = ?", arrayOf(requestId))
                .use { c -> if (c.moveToFirst()) Triple(c.getString(0), c.getString(1), c.getString(2)) else null }
                ?: return "Request not found"
            if (req.third != AppStore.STATUS_PENDING) return "This request is already ${req.third.lowercase()}"
            val need = req.second.takeWhile { it.isDigit() }.toIntOrNull() ?: 1
            val have = db.rawQuery("SELECT units FROM blood_stock WHERE bank_id = ? AND blood_group = ?",
                arrayOf(bankId.toString(), req.first)).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
            if (have < need) return "Not enough ${req.first} stock: $have unit(s) available, $need needed"
            db.execSQL("UPDATE blood_stock SET units = units - ? WHERE bank_id = ? AND blood_group = ?",
                arrayOf<Any>(need, bankId, req.first))
            db.update("requests", ContentValues().apply {
                put("status", "Fulfilled by " + bankName(bankId))
            }, "id = ?", arrayOf(requestId))
            db.setTransactionSuccessful()
            return null
        } finally {
            db.endTransaction()
        }
    }

    // --------------------------------------------------------------- statistics
    fun cityStats(): List<StatLine> {
        val list = ArrayList<StatLine>()
        list += StatLine("Approved blood banks", scalar("SELECT COUNT(*) FROM blood_banks WHERE status = 'APPROVED'").toString())
        list += StatLine("Registrations waiting for approval", scalar("SELECT COUNT(*) FROM blood_banks WHERE status = 'PENDING'").toString())
        list += StatLine("Blood bank administrators", scalar("SELECT COUNT(*) FROM users WHERE role = 1").toString())
        list += StatLine("Registered users", scalar("SELECT COUNT(*) FROM users WHERE role = 0").toString())
        list += StatLine("Donors", scalar("SELECT COUNT(*) FROM donors").toString())
        list += StatLine("Available donors", scalar("SELECT COUNT(*) FROM donors WHERE available = 1").toString())
        list += StatLine("Blood requests", scalar("SELECT COUNT(*) FROM requests").toString())
        list += StatLine("Open blood requests", scalar("SELECT COUNT(*) FROM requests WHERE status = ?", AppStore.STATUS_PENDING).toString())
        list += StatLine("Fulfilled blood requests", scalar("SELECT COUNT(*) FROM requests WHERE status LIKE 'Fulfilled%'").toString())
        list += StatLine("Donation requests waiting", scalar("SELECT COUNT(*) FROM donation_requests WHERE status = 'Pending'").toString())
        list += StatLine("Total units in stock (city)", scalar("SELECT SUM(units) FROM blood_stock s JOIN blood_banks b ON b.id = s.bank_id WHERE b.status = 'APPROVED'").toString())
        groups.forEach { g ->
            list += StatLine("City stock $g", scalar(
                "SELECT SUM(units) FROM blood_stock s JOIN blood_banks b ON b.id = s.bank_id " +
                    "WHERE b.status = 'APPROVED' AND s.blood_group = ?", g).toString() + " units")
        }
        return list
    }

    fun bankStats(bankId: Long): List<StatLine> {
        val id = bankId.toString()
        val stock = stockOf(bankId)
        val low = stock.filter { it.units < LOW_STOCK }.joinToString(", ") { it.bloodGroup }
        val list = ArrayList<StatLine>()
        list += StatLine("Donors registered with this bank", scalar("SELECT COUNT(*) FROM donors WHERE bank_id = ?", id).toString())
        list += StatLine("Total units in stock", stock.sumOf { it.units }.toString())
        list += StatLine("Low stock (under $LOW_STOCK units)", low.ifEmpty { "None" })
        list += StatLine("Donation requests waiting", scalar("SELECT COUNT(*) FROM donation_requests WHERE bank_id = ? AND status = 'Pending'", id).toString())
        list += StatLine("Donations approved", scalar("SELECT COUNT(*) FROM donation_requests WHERE bank_id = ? AND status = 'Approved'", id).toString())
        list += StatLine("Open blood requests in the city", scalar("SELECT COUNT(*) FROM requests WHERE status = ?", AppStore.STATUS_PENDING).toString())
        return list
    }

    const val LOW_STOCK = 5
}
