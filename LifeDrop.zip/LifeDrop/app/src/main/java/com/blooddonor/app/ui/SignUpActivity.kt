package com.blooddonor.app.ui

import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import com.blooddonor.app.data.AppStore
import com.blooddonor.app.databinding.ActivitySignupBinding

class SignUpActivity : AppCompatActivity() {
    private lateinit var b: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnSignUp.setOnClickListener { doSignUp() }
        b.tvLogin.setOnClickListener { finish() }
    }

    private fun doSignUp() {
        b.tilEtFullName.error = null
        b.tilEtPhone.error = null
        b.tilEtEmail.error = null
        b.tilEtPassword.error = null
        b.tilEtConfirmPassword.error = null

        val name = b.etFullName.text.toString().trim()
        val phone = b.etPhone.text.toString().trim()
        val email = b.etEmail.text.toString().trim()
        val password = b.etPassword.text.toString()
        val confirm = b.etConfirmPassword.text.toString()

        var valid = true
        if (name.length < 2) {
            b.tilEtFullName.error = "Enter your full name"; valid = false
        }
        if (phone.filter { it.isDigit() }.length < 10) {
            b.tilEtPhone.error = "Enter a valid 10-digit phone number"; valid = false
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            b.tilEtEmail.error = "Enter a valid email"; valid = false
        }
        if (password.length < 6) {
            b.tilEtPassword.error = "Use at least 6 characters"; valid = false
        }
        if (confirm != password) {
            b.tilEtConfirmPassword.error = "Passwords do not match"; valid = false
        }
        if (!valid) return

        if (!AppStore.register(name, phone, email, password)) {
            b.tilEtEmail.error = "An account with this email or phone already exists"
            return
        }
        toast("Account created")
        openHomeFresh()
    }
}
